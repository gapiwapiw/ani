#!/data/data/com.termux/files/usr/bin/sh
D="$HOME/ani"; U=http://127.0.0.1:1222
up(){ curl -s -m 1 -o /dev/null "$U/api/health"; }
case "$1" in
  stop) pkill -f "node server.js" && echo stopped ;;
  log) tail -n 40 "$D/server.log" ;;
  status) up && echo running || echo stopped ;;
  update) git -C "$HOME/ani-cli" pull; "$0" stop; sleep 1; exec "$0" ;;
  *)
    termux-wake-lock 2>/dev/null
    if ! up; then
      [ -f "$D/server.log" ] && [ "$(wc -c < "$D/server.log")" -gt 1000000 ] && : > "$D/server.log"
      (cd "$D" && nohup node server.js >> server.log 2>&1 &)
      n=0; until up || [ $n -ge 40 ]; do sleep 0.25; n=$((n+1)); done
    fi
    up || { echo "Server failed to start. See: ani log"; exit 1; }
    termux-open-url "$U" 2>/dev/null || am start -a android.intent.action.VIEW -d "$U" >/dev/null 2>&1 ;;
esac
