#!/bin/sh
cd "$(dirname "$0")" || exit 1
export ANI_CLI_PLAYER=debug
. ./lib.sh
case "$1" in
    search) hianime_search "$2" ;;
    page) hianime_curl "$(printf "$search_api" "$2")" ;;
    episodes) hianime_episodes "$2" ;;
    sources)
        episode_maps="${EPMAPS:-$(hianime_episodes "$2")}"
        hianime_m3u8 "$3" "$4" || { printf 'No sources found for ep %s (%s)\n' "$3" "$4" >&2; exit 1; }
        printf 'REFR\t%s\nMASTER\t%s\nSUB\t%s\nJSON\t%s\n' "$refr" "$_m3u8_master" "$sub_link" "$(printf '%s' "$_json" | tr -d '\n')"
        ;;
esac
