'use strict';
// Download manager: parallel HLS segment downloader with resume, priority-on-seek and offline playback.
const fs=require('fs'),path=require('path'),{pipeline}=require('stream/promises'),{Readable}=require('stream');
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const abs=(u,b)=>new URL(u,b).href;

function parseMaster(text,base){
  const L=text.split(/\r?\n/),vars=[],audio=[];
  for(let i=0;i<L.length;i++){
    const l=L[i].trim();
    if(l.startsWith('#EXT-X-STREAM-INF')){
      const bw=+(l.match(/BANDWIDTH=(\d+)/)||[])[1]||0,h=+(l.match(/RESOLUTION=\d+x(\d+)/)||[])[1]||0;
      const u=(L[i+1]||'').trim();
      if(u&&u[0]!=='#')vars.push({bw,h,url:abs(u,base)});
    }else if(l.startsWith('#EXT-X-MEDIA')&&/TYPE=AUDIO/.test(l)){
      const m=l.match(/URI="([^"]+)"/);
      if(m)audio.push({url:abs(m[1],base),def:/DEFAULT=YES/.test(l)});
    }
  }
  return{vars,audio};
}
function pick(vars,q){
  if(!vars.length)return null;
  const s=[...vars].sort((a,b)=>(b.h-a.h)||(b.bw-a.bw));
  if(!q||q==='best')return s[0];
  return s.find(v=>v.h&&v.h<=+q)||s[s.length-1];
}
// rewrite every URI in a media playlist to a local relative file name; collect unique resources
function localize(text,base,track,res,map){
  const out=text.split(/\r?\n/).map(raw=>{
    const l=raw.trim();if(!l)return'';
    const reg=u=>{const a=abs(u,base);let r=map.get(a);if(!r){r={u:a,f:track+res.length};res.push(r);map.set(a,r)}return r.f};
    if(l[0]!=='#')return reg(l);
    return l.replace(/URI="([^"]+)"/g,(m,x)=>'URI="'+reg(x)+'"');
  }).join('\n');
  return /#EXT-X-ENDLIST/.test(out)?out:out+'\n#EXT-X-ENDLIST\n';
}

module.exports=function createDL(o){
  const{dir,UA,curlText,resolve,BASE,fetchVtt}=o;
  const MAXITEMS=o.maxItems||2,MAXCONN=o.maxConn||16,START=o.startConn||8;
  fs.mkdirSync(dir,{recursive:true});
  const items=new Map();
  const hd=ref=>({'User-Agent':UA,Referer:ref||BASE});
  let tmpN=0;

  function mk(meta){
    const it={key:meta.key,dir:path.join(dir,meta.key),meta,state:meta.state||'queued',done:new Set(),bytes:0,
      pending:[],inflight:0,cursor:0,fails:{},nerr:0,target:START,streak:0,waiters:new Map(),byFile:{},
      res:meta.res||null,refr:meta.refr||BASE,speed:0,lastBytes:0,stalled:false,err:meta.err||'',saveT:0,finished:false};
    indexRes(it);return it;
  }
  function indexRes(it){it.byFile={};(it.res||[]).forEach((r,i)=>{r.i=i;it.byFile[r.f]=r})}
  function save(it){
    const m=it.meta;m.state=it.state;m.bytes=it.bytes;m.res=it.res;m.err=it.err;m.refr=it.refr;
    try{const p=path.join(it.dir,'meta.json');fs.writeFileSync(p+'.tmp',JSON.stringify(m));fs.renameSync(p+'.tmp',p)}catch{}
  }
  function saveSoon(it){if(it.saveT)return;it.saveT=setTimeout(()=>{it.saveT=0;save(it)},3000)}

  function loadAll(){
    for(const k of fs.readdirSync(dir)){
      const d=path.join(dir,k);
      try{
        const it=mk(JSON.parse(fs.readFileSync(path.join(d,'meta.json'),'utf8')));
        for(const f of fs.readdirSync(d)){
          if(f.endsWith('.part'))fs.rmSync(path.join(d,f),{force:true});
          else if(it.byFile[f]){it.done.add(f);it.bytes+=fs.statSync(path.join(d,f)).size}
        }
        if(it.res&&it.res.length&&it.done.size>=it.res.length)it.state='done';
        else if(['downloading','preparing','queued'].includes(it.state))it.state='queued';
        items.set(k,it);
      }catch{}
    }
  }

  async function plan(masterUrl,refr,q){
    const mt=await curlText(masterUrl,refr);
    if(!/^#EXTM3U/m.test(mt))throw new Error('Bad playlist (blocked or offline)');
    let vurl=masterUrl,vt=mt,au=null,bw=0,h=0;
    if(/#EXT-X-STREAM-INF/.test(mt)){
      const{vars,audio}=parseMaster(mt,masterUrl),v=pick(vars,q);
      if(!v)throw new Error('No video variants');
      vurl=v.url;bw=v.bw;h=v.h;au=audio.find(a=>a.def)||audio[0]||null;
      vt=await curlText(vurl,refr);
    }
    if(!/#EXTINF/.test(vt))throw new Error('Bad media playlist');
    const res=[],map=new Map(),files={};
    files['v.m3u8']=localize(vt,vurl,'v',res,map);
    if(au)files['a.m3u8']=localize(await curlText(au.url,refr),au.url,'a',res,map);
    files['master.m3u8']='#EXTM3U\n'+(au?'#EXT-X-MEDIA:TYPE=AUDIO,GROUP-ID="a",NAME="Audio",DEFAULT=YES,AUTOSELECT=YES,URI="a.m3u8"\n':'')+
      '#EXT-X-STREAM-INF:BANDWIDTH='+(bw||2000000)+(h?',RESOLUTION='+Math.round(h*16/9)+'x'+h:'')+(au?',AUDIO="a"':'')+'\nv.m3u8\n';
    let duration=0;for(const m of vt.matchAll(/#EXTINF:([\d.]+)/g))duration+=+m[1];
    return{files,res,duration,h};
  }

  async function prepare(it){
    const m=it.meta,s=await resolve(m.id,m.ep,m.mode);
    if(!s||!s.master)throw new Error('No source found');
    it.refr=s.refr||BASE;
    const p=await plan(s.master,it.refr,m.q);
    fs.mkdirSync(it.dir,{recursive:true});
    for(const[f,t]of Object.entries(p.files))fs.writeFileSync(path.join(it.dir,f),t);
    it.res=p.res;indexRes(it);
    m.duration=p.duration;m.h=p.h;m.total=p.res.length;
    m.subs=(s.subs||[]).map((t,i)=>({label:t.label||t.lang||t.language||'Track '+(i+1),src:t.src||t.file||t.url,file:'sub'+i+'.vtt',def:!!t.default})).filter(t=>t.src);
    for(const x of m.xsubs||[])m.subs.push(xsub(m.subs,x));
    save(it);
  }
  const xsub=(have,x)=>({label:x.label,lang:x.lang,src:x.url,file:'x'+have.filter(t=>t.ext).length+'.vtt',def:false,ext:true});
  async function extras(it){
    const m=it.meta;
    for(const t of m.subs||[]){
      const f=path.join(it.dir,t.file);if(fs.existsSync(f))continue;
      try{
        if(t.ext){const txt=await fetchVtt(t.src);if(txt)fs.writeFileSync(f,txt)}
        else{const r=await fetch(t.src,{headers:hd(it.refr),signal:AbortSignal.timeout(20000)});if(r.ok)fs.writeFileSync(f,Buffer.from(await r.arrayBuffer()))}
      }catch{}
    }
    const pf=path.join(it.dir,'poster');
    if(m.thumb&&!fs.existsSync(pf)){
      try{const r=await fetch(m.thumb,{headers:hd(BASE),signal:AbortSignal.timeout(20000)});if(r.ok)fs.writeFileSync(pf,Buffer.from(await r.arrayBuffer()))}catch{}
    }
  }

  async function getRes(it,r){
    const dst=path.join(it.dir,r.f),tmp=dst+'.'+(++tmpN)+'.part';
    let resp;
    try{resp=await fetch(r.u,{headers:hd(it.refr),signal:AbortSignal.timeout(45000)})}
    catch(e){throw new Error(e.message||'network')}
    if(!resp.ok){try{await resp.body.cancel()}catch{}const e=new Error('HTTP '+resp.status);e.status=resp.status;throw e}
    try{await pipeline(Readable.fromWeb(resp.body),fs.createWriteStream(tmp))}
    catch(e){fs.rmSync(tmp,{force:true});throw new Error(e.message||'network')}
    const sz=fs.statSync(tmp).size,cl=+resp.headers.get('content-length')||0;
    if(cl&&!resp.headers.get('content-encoding')&&sz!==cl){fs.rmSync(tmp,{force:true});throw new Error('truncated')}
    fs.renameSync(tmp,dst);
    return sz;
  }

  function nextIdx(it){const p=it.pending;if(!p.length)return -1;let k=p.findIndex(i=>i>=it.cursor);if(k<0)k=0;return p.splice(k,1)[0]}
  function requeue(it,i){const p=it.pending,k=p.findIndex(x=>x>i);if(k<0)p.push(i);else p.splice(k,0,i)}
  function wake(it,f,v){const w=it.waiters.get(f);if(w){it.waiters.delete(f);w.forEach(fn=>fn(v))}}
  function wakeAll(it,v){for(const f of[...it.waiters.keys()])wake(it,f,v)}
  function fail(it,msg){if(it.state!=='downloading')return;it.state='error';it.err=msg;it.stalled=false;wakeAll(it,false);save(it);schedule()}
  function finish(it){
    if(it.finished||it.state!=='downloading')return;it.finished=true;
    if(it.done.size>=it.res.length){it.state='done';it.stalled=false;it.err=''}
    else{it.state='error';it.err='Incomplete, tap resume'}
    save(it);schedule();
  }
  async function refresh(it){
    if(it.refreshing)return;it.refreshing=true;
    try{
      const m=it.meta,s=await resolve(m.id,m.ep,m.mode),p=await plan(s.master,s.refr,m.q);
      if(p.res.length===it.res.length){p.res.forEach((r,i)=>{it.res[i].u=r.u});it.refr=s.refr||it.refr;it.fails={}}
    }catch{}finally{it.refreshing=false}
  }

  async function worker(it,n){
    while(it.state==='downloading'){
      if(n>=it.target){await sleep(250);continue}
      const i=nextIdx(it);
      if(i<0){if(it.inflight===0){finish(it);return}await sleep(120);continue}
      it.inflight++;const r=it.res[i];
      try{
        const sz=await getRes(it,r);
        it.bytes+=sz;it.done.add(r.f);it.stalled=false;it.nerr=0;
        wake(it,r.f,true);saveSoon(it);
        if(++it.streak>=6&&it.target<MAXCONN){it.target++;it.streak=0}
      }catch(e){
        it.streak=0;requeue(it,i);
        if(!e.status){it.stalled=true;it.target=Math.max(2,it.target-1);await sleep(Math.min(8000,500*2**Math.min(++it.nerr,4)))}
        else{
          const f=it.fails[i]=(it.fails[i]||0)+1;
          if(e.status===429)it.target=Math.max(2,it.target>>1);
          if(f===3&&[401,403,410].includes(e.status))await refresh(it);
          if(f>=8)fail(it,'HTTP '+e.status);else await sleep(Math.min(6000,400*2**f));
        }
      }finally{it.inflight--}
    }
  }

  async function run(it){
    it.state='preparing';it.err='';
    try{
      if(!it.res){await prepare(it);if(it.state!=='preparing')return}
      it.state='downloading';it.finished=false;
      it.pending=it.res.map((r,i)=>i).filter(i=>!it.done.has(it.res[i].f));
      it.cursor=0;it.fails={};it.nerr=0;it.target=START;it.streak=0;it.inflight=0;
      save(it);extras(it);
      if(!it.pending.length){finish(it);return}
      for(let n=0;n<MAXCONN;n++)worker(it,n);
    }catch(e){
      if(it.state==='preparing'||it.state==='downloading'){it.state='error';it.err=e.message}
      save(it);schedule();
    }
  }
  function schedule(){
    let active=[...items.values()].filter(i=>i.state==='preparing'||i.state==='downloading').length;
    for(const it of items.values()){
      if(active>=MAXITEMS)break;
      if(it.state==='queued'){active++;run(it)}
    }
  }

  function start(p){
    const mode=p.mode==='dub'?'dub':'sub',key=p.id+'~'+p.ep+'~'+mode;
    let it=items.get(key);
    const xs=(Array.isArray(p.subs)?p.subs:[]).filter(x=>x&&/^https?:/.test(x.url||'')).slice(0,8).map(x=>({lang:String(x.lang||'').slice(0,8),label:String(x.label||x.lang||'Subtitles').slice(0,60),url:x.url}));
    if(it){
      if(it.state!=='done')resume(key);
      if(xs.length){
        const m=it.meta,cur=m.subs||[],fresh=xs.filter(x=>!cur.some(t=>t.ext&&t.label===x.label)&&!(m.xsubs||[]).some(t=>t.label===x.label));
        if(fresh.length){
          if(m.subs){for(const x of fresh)m.subs.push(xsub(m.subs,x));save(it);extras(it)}
          else{m.xsubs=[...(m.xsubs||[]),...fresh];save(it)}
        }
      }
      return key}
    try{const s=fs.statfsSync(dir);if(s.bavail*s.bsize<300e6)throw new Error('Low storage (under 300 MB free)')}
    catch(e){if(/Low storage/.test(e.message))throw e}
    fs.mkdirSync(path.join(dir,key),{recursive:true});
    it=mk({key,id:p.id,name:p.name||p.id,label:p.label||'',thumb:p.thumb||'',ep:String(p.ep),mode,q:p.q||'best',xsubs:xs,created:Date.now(),state:'queued'});
    items.set(key,it);save(it);schedule();return key;
  }
  function resume(key){const it=items.get(key);if(it&&(it.state==='paused'||it.state==='error')){it.state='queued';it.err='';schedule()}}
  function pause(key){
    const it=items.get(key);if(!it)return;
    if(['downloading','preparing','queued'].includes(it.state)){it.state='paused';it.stalled=false;wakeAll(it,false);save(it);schedule()}
  }
  function remove(key){
    const it=items.get(key);if(!it)return;
    it.state='removed';wakeAll(it,false);clearTimeout(it.saveT);items.delete(key);
    fs.rmSync(it.dir,{recursive:true,force:true});schedule();
  }

  // serve a local file; if it's not on disk yet, prioritise it and wait, or fetch it directly
  async function file(key,f){
    const it=items.get(key);
    if(!it||!/^[\w.-]+$/.test(f)||f==='meta.json'||f.endsWith('.part')||f.endsWith('.tmp'))return null;
    const p=path.join(it.dir,f);
    if(fs.existsSync(p))return p;
    const r=it.byFile[f];if(!r)return null;
    if(it.state==='downloading'){
      it.cursor=r.i;
      const ok=await new Promise(res=>{
        const t=setTimeout(()=>res(false),40000);
        let a=it.waiters.get(f);if(!a)it.waiters.set(f,a=[]);
        a.push(v=>{clearTimeout(t);res(v)});
      });
      if(ok&&fs.existsSync(p))return p;
    }
    try{const sz=await getRes(it,r);it.bytes+=sz;it.done.add(f);saveSoon(it);return p}catch{return null}
  }

  function list(){
    return[...items.values()].map(it=>{
      const m=it.meta,total=it.res?it.res.length:0,done=it.done.size;
      return{key:it.key,id:m.id,name:m.name,label:m.label||'',thumb:m.thumb,ep:m.ep,mode:m.mode,q:m.q,h:m.h||0,state:it.state,err:it.err,
        stalled:it.stalled,done,total,pct:total?Math.floor(done*100/total):0,bytes:it.bytes,speed:it.speed|0,conn:it.target,
        duration:m.duration||0,created:m.created,poster:fs.existsSync(path.join(it.dir,'poster')),
        eta:it.speed>0&&done>0&&total>done?Math.round((it.bytes/done)*(total-done)/it.speed):0,
        subs:(m.subs||[]).filter(t=>fs.existsSync(path.join(it.dir,t.file))).map(t=>({label:t.label,file:t.file,def:t.def,ext:!!t.ext,lang:t.lang||''}))};
    }).sort((a,b)=>b.created-a.created);
  }
  function flush(){for(const it of items.values()){clearTimeout(it.saveT);save(it)}}
  setInterval(()=>{
    for(const it of items.values()){
      const d=it.bytes-it.lastBytes;it.lastBytes=it.bytes;
      it.speed=it.state==='downloading'?Math.round(it.speed*.5+d*.5):0;
    }
  },1000).unref();

  loadAll();schedule();
  return{start,pause,resume,remove,list,file,flush,items};
};
