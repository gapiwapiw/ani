'use strict';
// Groups hianime search results (one entry per season/movie/arc) into one card per franchise.
const STOP=new Set(['the','a','an','of','my','no','to','and','in','on','wa','ga','is','for']);
const TYPEKW=/\b(movie|movies|film|ova|oad|ona|special|specials|recap|recaps|pv|pvs|arc|arcs)\b/i;
const ORD={first:1,second:2,third:3,fourth:4,fifth:5,sixth:6,seventh:7,eighth:8,ninth:9,tenth:10};
const ROMAN={ii:2,iii:3,iv:4,v:5,vi:6,vii:7,viii:8};
const norm=w=>w.toLowerCase().replace(/[^\p{L}\p{N}]+/gu,'');
const idNum=id=>+(String(id).match(/-(\d+)$/)||[])[1]||0;

// split a title into tokens, pull out season / part / type markers, return the remaining "core" tokens
function parse(name){
  let s=String(name).replace(/\((tv|tv series)\)/ig,' ').replace(/\s+tv$/i,'').replace(/[–—]/g,' - ');
  let toks=s.split(/\s+/).map(raw=>({raw,n:norm(raw)})).filter(t=>t.n);
  let season=0,part=0,fin=false,type=TYPEKW.test(s);
  const n=toks.map(t=>t.n),drop=new Set();
  const mark=(i,len=1)=>{for(let k=0;k<len;k++)drop.add(i+k)};
  for(let i=0;i<n.length;i++){
    const w=n[i],nx=n[i+1],pv=n[i-1];
    if(w==='season'&&/^\d+$/.test(nx||'')){season=+nx;mark(i,2)}
    else if(w==='season'&&ORD[nx]){season=ORD[nx];mark(i,2)}
    else if(w==='season'&&ORD[pv]&&!drop.has(i-1)){season=ORD[pv];mark(i-1,2)}
    else if(w==='season'&&/^\d+(st|nd|rd|th)$/.test(pv||'')&&!drop.has(i-1)){season=parseInt(pv);mark(i-1,2)}
    else if(w==='season'&&pv==='final'){fin=true;mark(i-1,2);if(n[i-2]==='the')mark(i-2)}
    else if(/^\d+(st|nd|rd|th)$/.test(w)&&nx==='season'){}
    else if(w==='part'&&/^\d+$/.test(nx||'')){part=+nx;mark(i,2)}
    else if(w==='cour'&&/^\d+$/.test(nx||'')){part=+nx;mark(i,2)}
  }
  if(!season&&!fin&&!type){
    const L=n.length-1,w=n[L];
    if(L>0&&!drop.has(L)){
      if(ROMAN[w]){season=ROMAN[w];mark(L)}
      else if(/^[2-9]$/.test(w)&&!/^\d+$/.test(n[L-1])){season=+w;mark(L)}
    }
  }
  const core=toks.filter((_,i)=>!drop.has(i));
  return{core,season,part,fin,type};
}
const key=ts=>ts.map(t=>t.n).join(' ');
const meaningful=ts=>ts.some(t=>!STOP.has(t.n))&&key(ts).length>=5;
const clean=ts=>ts.map(t=>t.raw).join(' ').replace(/^[\s:,\-–]+|[\s:,\-–]+$/g,'').replace(/\s*[:,]\s*/g,': ').replace(/^:\s*/,'');

function group(results){
  const items=results.map((r,i)=>({...r,i,p:parse(r.name)}));
  // franchise roots: an entry's core is a token-prefix of another's, or two entries share >=2 leading tokens
  const roots=[];
  const isPrefix=(a,b)=>a.length<=b.length&&a.every((t,i)=>t.n===b[i].n);
  const sorted=[...items].sort((a,b)=>a.p.core.length-b.p.core.length||a.i-b.i);
  const assign=new Map();
  for(const it of sorted){
    const c=it.p.core;let root=roots.find(r=>isPrefix(r.toks,c));
    if(!root){
      // common leading tokens with an already placed entry
      for(const o of sorted){if(o===it||!assign.has(o))continue;
        let k=0;const oc=o.p.core;while(k<c.length&&k<oc.length&&c[k].n===oc[k].n)k++;
        if(k>=2&&meaningful(c.slice(0,k))){const toks=c.slice(0,k);root=roots.find(r=>isPrefix(r.toks,toks)&&r.toks.length===toks.length);
          if(!root){root={toks,items:[]};roots.push(root);
            // pull the earlier entry out of its own root into this one
            const old=assign.get(o);if(old!==root){old.items=old.items.filter(x=>x!==o);root.items.push(o);assign.set(o,root)}}
          break}}
    }
    if(!root){root={toks:c.length?c:[{raw:it.name,n:norm(it.name)}],items:[]};roots.push(root)}
    root.items.push(it);assign.set(it,root);
  }
  const groups=[];
  for(const root of roots){
    if(!root.items.length)continue;
    const rk=key(root.toks),its=root.items;
    for(const it of its){
      const rem=it.p.core.slice(root.toks.length);
      it.rem=rem;it.remKey=key(rem);
      it.extra=it.p.type||(rem.length>0&&!it.p.season&&!it.p.fin&&!it.p.part)||it.p.type;
    }
    // season-1 candidate: unmarked entry whose core == root; else shortest unmarked non-extra entry
    let s1=its.find(x=>!x.p.season&&!x.p.fin&&!x.p.part&&!x.p.type&&x.rem.length===0);
    if(!s1){const c=its.filter(x=>!x.p.season&&!x.p.fin&&!x.p.type&&!TYPEKW.test(x.name)&&!/\barc\b/i.test(x.name));
      s1=c.sort((a,b)=>key(a.p.core).length-key(b.p.core).length||idNum(a.id)-idNum(b.id))[0]}
    const s1rem=s1?s1.rem.map(t=>t.n):[];
    if(s1rem.length)for(const it of its){if(it!==s1&&it.rem.length>s1rem.length&&s1rem.every((w,k)=>it.rem[k].n===w))it.rem=it.rem.slice(s1rem.length)}
    const maxNum=Math.max(1,...its.map(x=>x.p.season||0));
    const seasons=[];
    for(const it of its){
      let kind,num=0;
      if(it===s1){kind='season';num=1}
      else if(it.p.type){kind='other'}
      else if(it.p.fin){kind='season';num=maxNum+1}
      else if(it.p.season){kind='season';num=it.p.season}
      else if(it.p.part&&it.rem.length===0){kind='season';num=it.p.part>=2?1:1}   // "X Part 2" of season 1
      else kind='other';
      seasons.push({id:it.id,name:it.name,thumb:it.thumb,kind,num,part:it.p.part||0,fin:it.p.fin,rem:it.rem,type:it.p.type,i:it.i});
    }
    // labels
    const bynum={};seasons.filter(s=>s.kind==='season').forEach(s=>(bynum[s.num]=bynum[s.num]||[]).push(s));
    for(const s of seasons){
      if(s.kind==='season'){
        const multi=bynum[s.num].length>1;
        s.label=(s.fin?'Final Season':'Season '+s.num)+(s.part&&multi?' · Part '+s.part:'');
      }else s.label=clean(s.rem)||s.name;
      s.label=s.label.length>34?s.label.slice(0,33)+'…':s.label;
    }
    seasons.sort((a,b)=>{
      const ka=a.kind==='season'?0:a.type?2:1,kb=b.kind==='season'?0:b.type?2:1;
      return ka-kb||(a.num-b.num)||(a.part-b.part)||(idNum(a.id)-idNum(b.id))||a.i-b.i});
    // group display name + poster from season 1 (or first season)
    const lead=seasons.find(s=>s.kind==='season')||seasons[0];
    const base=(lead.kind==='season'&&s1&&s1.id===lead.id)?clean(s1.p.core):clean(root.toks.map((t,i)=>its[0].p.core[i]||t));
    groups.push({key:rk.replace(/\s+/g,'-'),name:base||lead.name,thumb:lead.thumb||(seasons.find(s=>s.thumb)||{}).thumb||'',seasons:seasons.map(({id,name,thumb,kind,num,part,label,fin,type})=>({id,name,thumb,kind,num,part,label,fin:!!fin,type:!!type})),first:Math.min(...its.map(x=>x.i))});
  }
  return groups.sort((a,b)=>a.first-b.first);
}
module.exports={group,parse};
