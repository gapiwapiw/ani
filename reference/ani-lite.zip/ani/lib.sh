#!/bin/sh

version_number="5.1.8"

# UI

# shellcheck disable=SC2086
# $1 = prompt, $2 = multi select flag (for fzf/rofi), $3 = extra flags by user
menu() {
    case "$menu_program" in
        fzf) fzf --reverse --cycle --prompt "$1" $2 $3 ;;
        rofi) rofi -sort -dmenu -i -p "$1" $2 $3 ;;
        dmenu) dmenu -l 20 -p "$1" $3 ;;
        *) "$menu_program" $3 "$1" ;;
    esac
}

# provide menu. input format is either (ep_list) or (number \t anime_id \t anime_name)
nth() {
    _stdin=$(cat -)
    [ -z "$_stdin" ] && return 1
    _line_count="$(printf "%s\n" "$_stdin" | wc -l | tr -d "[:space:]")"
    [ "$_line_count" -eq 1 ] && printf "%s" "$_stdin" | cut -f 2,3 && return 0
    _prompt="$1"
    [ $# -ne 1 ] && _multi_flag="$2"
    _line=$(printf "%s" "$_stdin" | cut -f 1,3 | tr '\t' ' ' | menu "$_prompt" "$_multi_flag" "$menu_extra_flags" | cut -d " " -f 1)
    _line_start=$(printf "%s" "$_line" | head -n 1)
    _line_end=$(printf "%s" "$_line" | tail -n 1)
    [ -n "$_line" ] || return 1
    if [ "$_line_start" = "$_line_end" ]; then
        printf "%s" "$_stdin" | grep -E '^'"${_line}"'($|[[:space:]])' | cut -f 2,3 || return 1
    else
        printf "%s" "$_stdin" | sed -n '/^'"${_line_start}"'$/,/^'"${_line_end}$"'/p' || return 1
    fi
}

die() {
    printf "\33[2K\r\033[1;31m%s\033[0m\n" "$*" >&2
    exit 1
}

info() {
    printf "\33[2K\r\033[1;34m%s\033[0m\n" "$*"
}

help_info() {
    printf "
    Usage:
    %s [options] [query]
    %s [query] [options]
    %s [options] [query] [options]

    Options:
      -c, --continue
        Continue watching from history
      -d, --download
        Download the video instead of playing it
      -D, --delete
        Delete history
      -l, --logview
        Show logs
      -s, --syncplay
        Use Syncplay to watch with friends
      -S, --select-nth
        Select nth entry
      -q, --quality
        Specify the video quality
      -v, --vlc
        Use VLC to play the video
      -V, --version
        Show the version of the script
      -h, --help
        Show this help message and exit
      -e, --episode, -r, --range
        Specify the number of episodes to watch
      --dub
        Play dubbed version
      --rofi
        Use rofi instead of fzf for the interactive menu
      --dmenu
        Use dmenu instead of fzf for the interactive menu
      --skip
        Use ani-skip to skip the intro of the episode (mpv only)
      --no-detach
        Don't detach the player (useful for in-terminal playback, mpv only)
      --exit-after-play
        Exit the player, and return the player exit code (useful for non interactive scenarios)
      -N, --nextep-countdown
        Display a countdown to the next episode
      -U, --update
        Update the script
    Some example usages:
      %s -q 720p banana fish
      %s --skip -S 2 one piece
      %s -d -e 2 cyberpunk edgerunners
      %s --vlc cyberpunk edgerunners -q 1080p -e 4
      %s blue lock -e 5-6
      %s -e \"5 6\" blue lock
    \n" "${0##*/}" "${0##*/}" "${0##*/}" "${0##*/}" "${0##*/}" "${0##*/}" "${0##*/}" "${0##*/}" "${0##*/}"
    exit 0
}

version_info() {
    printf "%s\n" "$version_number"
    exit 0
}

# Bookkeeping

update_script() {
    info "[branch:$branch] Checking for Update.."
    update="$($curl_exe --fail-with-body -sL -A "$agent" "https://raw.githubusercontent.com/pystardust/ani-cli/$branch/ani-cli")" || die "[branch:$branch] Connection error: $update"
    new_version="$(printf "%s" "$update" | sed -nE 's|^version_number="([^"]+)"$|\1|p')"
    [ -z "$new_version" ] && die "[branch:$branch] Invalid response."
    printf "%s" "$update" | grep -q "^version_number" || die "[branch:$branch] Invalid response."
    update="$(printf "%s\n" "$update" | diff -u "$0" -)"
    if [ -z "$update" ]; then
        info "[branch:$branch] Script is up to date :) ($version_number)"
    else
        if printf "%s\n" "$update" | patch "$0" -; then
            info "[branch:$branch] Updated: $version_number -> $new_version"
        else
            die "[branch:$branch] Failed to update. Read the above line!"
        fi
    fi
    exit 0
}

# checks if dependencies are present
dep_ch() {
    command -v "$1" >/dev/null || die "Program $1 not found. Please install it."
}

# checks for deps in order and returns the first available. format is "prog_a,prog_b,prog_c"
dep_ch_failover() {
    [ -z "$1" ] && return 1
    prog=${1%%,*}
    command -v "$prog" >/dev/null 2>&1 && printf "%s" "$prog" && return 0
    [ -e "$prog" ] && printf "%s" "$prog" && return 0
    [ "$1" != "$prog" ] && dep_ch_failover "${1#*,}"
}

cleanup() {
    [ "$player_function" = "android_mpv" ] && : >"/storage/emulated/0/mpv/mpv.config.mp4" 2>/dev/null
    tput sgr0               # clears colors
    rm -f "${histfile}.new" # remove temp logfile
}

# SCRAPING

#shellcheck disable=SC2086
hianime_curl() {
    _curl_status=0
    _response="$($curl_exe -sL -A "$agent" --max-time 10 $cipher_flag \
        -w ' %{http_code}' "$@")" || _curl_status=$?

    _http_code=${_response##* }
    _response=${_response% *}

    if [ "$_curl_status" -ne 0 ]; then
        case "$_http_code" in
            [1-5][0-9][0-9]) _detail="HTTP $_http_code" ;;
            *) _detail="no HTTP response" ;;
        esac
        die "Connection error: could not fetch $1 ($_detail; curl exit $_curl_status)"
    fi

    case "$_http_code" in
        2??) ;;
        *) printf "%s" "$_response" | grep -qi "Just a moment" ||
            die "Request failed: HTTP $_http_code from $1" ;;
    esac

    printf "%s" "$_response"
}

# GNU, BSD and openssl spell base64 decoding differently
b64_decode() {
    printf "%s\n" "$1" | base64 -d 2>/dev/null || printf "%s\n" "$1" | base64 -D 2>/dev/null || printf "%s\n" "$1" | openssl base64 -d -A 2>/dev/null
}

# the embed page ships its config as base64(json XOR "otaku-embed-v1"), this prints the json.
# runs in a subshell so the key bytes can live in the positional parameters and rotate with shift.
deobfuscate_blob() (
    _bytes="$(b64_decode "$1" | od -v -An -tu1)"
    set -- 111 116 97 107 117 45 101 109 98 101 100 45 118 49
    _output=""
    for _byte in $_bytes; do
        _char=$((_byte ^ $1))
        _output="${_output}\\0$((_char + 2 * (_char / 8) + 20 * (_char / 64)))"
        shift
        if [ "$#" -eq 0 ]; then
            printf "%b" "$_output" && _output="" || return
            set -- 111 116 97 107 117 45 101 109 98 101 100 45 118 49
        fi
    done
    printf "%b" "$_output"
)

# search the query and give results. format is (id \t name)
hianime_search() {
    #shellcheck disable=SC2059
    _page="$(hianime_curl "$(printf "$search_api" "$1")")" || return 1
    if printf "%s" "$_page" | grep -qi "<title>Just a moment"; then
        [ "$curl_exe" = "curl" ] && die "Blocked by cloudflare. Try installing curl-impersonate"
        die "Blocked by cloudflare."
    fi
    # the top 10 sidebar repeats the result markup, cut it off before flattening the page
    printf "%s" "$_page" | sed '/id="main-sidebar"/,$d' | tr '\n' ' ' | sed 's|<div class="film-detail">|\n<div class="film-detail">|g' |
        sed -nE 's|.*<h3 class="film-name">[[:space:]]*<a href="[^"]*/([^"/]*)"[[:space:]]*title="([^"]*)".*|\1\t\2|p' |
        sed -e "s|&#039;|'|g" -e 's|&quot;|"|g' -e "s|&amp;|\&|g"
}

# get the episodes list of the selected anime. format is (id \t ep_no)
hianime_episodes() {
    #shellcheck disable=SC2059
    _page="$(hianime_curl "$(printf "$episodes_api" "${1##*-}")")" || return 1
    # ids from the v5.0 provider have the same shape, so check the slug in the episode links too
    printf "%s" "$_page" | sed 's|\\||g; s|ep-item|\nep-item|g' |
        sed -nE "s|.*data-number=\"([^\"]*)\".*data-id=\"([0-9]+)\".*/watch/${1}[?]ep=.*|\\2\\t\\1|p"
}

# resolves episode $1 in mode $2 (sub/dub): sets links (quality >url per line), sub_link, mal_id and refr
hianime_m3u8() {
    _ep_id=$(printf "%s" "$episode_maps" | sed -nE "s|^([0-9]+)\t${1}$|\1|p")
    #shellcheck disable=SC2059
    _servers="$(hianime_curl "$(printf "$servers_api" "$_ep_id")" | sed 's|\\"|"|g; s|server-item|\nserver-item|g')"
    # only the zokoanime embed is understood by deobfuscate_blob, the other servers use different players
    _hash="$(printf "%s\n" "$_servers" | sed -nE 's|.*data-type="'"$2"'".*data-server-name="ZokoAnime".*data-hash="([^"]*)".*|\1|p' | head -n 1)"
    _embed="$(b64_decode "$_hash")"
    [ -z "$_embed" ] && return 1
    # the stream host wants the embed site as referer, and the embed url carries the mal id for ani-skip
    refr="$(printf "%s" "$_embed" | sed -E 's|^(https?://[^/]*).*|\1/|')"
    mal_id="$(printf "%s" "$_embed" | sed -nE 's|.*/mal/([0-9]+)/.*|\1|p')"
    _blob="$(hianime_curl "$_embed" | sed -nE 's|.*window\.__P="([^"]*)".*|\1|p')"
    [ -z "$_blob" ] && return 1
    _json="$(deobfuscate_blob "$_blob")"
    _m3u8_master="$(printf "%s" "$_json" | sed -nE 's|.*"src":"([^"]*\.m3u8[^"]*)".*|\1|p')"
    [ -z "$_m3u8_master" ] && return 1
    sub_link="$(printf "%s" "$_json" | sed 's|.*"subtitles":\[||; s|}\].*||; s|},{|}\n{|g' | grep -m 1 '"default":true' | sed -nE 's|.*"src":"([^"]*)".*|\1|p')"
    _playlist="$(hianime_curl "$_m3u8_master" -e "$refr")"
    # quality variants are relative to the master playlist
    links="$(printf "%s\n" "$_playlist" | sed 's|^#EXT-X-STREAM.*x||g; s|,.*|p|g; /^#/d; $!N; s|\n| >|;/EXT-X-I-FRAME/d' | sed "\|>https*://|!s|>|>${_m3u8_master%/*}/|" | sort -g -r -s)"
    audio_link="$(printf "%s\n" "$_playlist" | sed -nE '/^#EXT-X-MEDIA:TYPE=AUDIO,.*DEFAULT=YES/{s|.*URI="([^"]*)".*|\1|p;q;}' | sed "\|^https*://|!s|^|${_m3u8_master%/*}/|")"
    [ -n "$links" ]
}

# select the quality according to the setting
select_quality() {
    case "$1" in
        best) _result=$(printf "%s" "$links" | head -n 1) ;;
        worst) _result=$(printf "%s" "$links" | grep -E '^[0-9]{3,4}' | tail -n 1) ;;
        *) _result=$(printf "%s" "$links" | grep -m 1 "$1") ;;
    esac
    [ -z "$_result" ] && printf "\33[2K\r\033[1;33m%s\033[0m\n" "$1 not found, defaulting to best" >&2 && _result=$(printf "%s" "$links" | head -n 1)

    video_link=$(printf "%s" "$_result" | cut -d ">" -f 2)
}

# gets embed url, collects direct links and selects one with desired quality into $episode
get_video_link() {
    hianime_m3u8 "$ep_no" "$mode" || die "No sources found for $mode!"
    info "hianime.at links fetched"
    select_quality "$quality"
    # should never trigger but just in case
    if printf "%s" "$ep_list" | grep -q "^$ep_no$"; then
        [ -z "$video_link" ] && die "Episode is released, but no valid sources!"
    else
        [ -z "$video_link" ] && die "Episode not released!"
    fi
}

# provide countdown for the next episode release both sub and dub
time_until_next_ep() {
    animeschedule="https://animeschedule.net"
    _query="$(printf "%s" "$*" | tr ' ' '+')"
    $curl_exe -s -G "$animeschedule/api/v3/anime" --data "q=${_query}" | sed 's|},{"id"|\n|g' | while read -r _entry; do
        _route=$(printf "%s" "$_entry" | sed -nE 's|.*"route":"([^"]*)",.*|\1|p')
        _eng_title=$(printf '%s' "$_entry" | sed -nE 's|.*"english":"([^"]*)".*|\1|p')
        [ -z "$_eng_title" ] && _eng_title=$(printf '%s' "$_entry" | sed -nE 's|.*,"title":"([^"]*)".*|\1|p')
        [ -z "$_eng_title" ] && _eng_title="N/A"
        _jpn_title=$(printf '%s' "$_entry" | sed -nE 's|.*"romaji":"([^"]*)".*|\1|p')
        [ -z "$_jpn_title" ] && _jpn_title="N/A"
        _status=$(printf '%s' "$_entry" | sed -nE 's|.*"status":"([^"]*)".*|\1|p')
        [ -z "$_status" ] && _status="Unknown"

        case "$_status" in
            Ongoing) _color="33" ;;
            Finished) _color="32" ;;
            *) _color="36" ;;
        esac

        printf "Eng: %s\n" "$_eng_title"
        printf "Jpn: %s\n" "$_jpn_title"
        printf "Status: \033[1;%sm%s\033[0m\n" "$_color" "$_status"

        if [ "$_status" != "Finished" ]; then
            _page="$($curl_exe -s "$animeschedule/anime/$_route")"
            _sub_ep=$(printf "%s" "$_page" | sed -nE 's|.*release-time-type-subs"[^>]*><span class="release-time-episode-number">Episode ([0-9]+)</span>.*|\1|p' | head -n 1)
            _dub_ep=$(printf "%s" "$_page" | sed -nE 's|.*release-time-type-dub"[^>]*><span class="release-time-episode-number">Episode ([0-9]+)</span>.*|\1|p' | head -n 1)
            _sub_countdown=$(printf "%s" "$_page" | sed -nE 's|.*class="countdown-time" datetime="([^"]*)".*|\1|p' | head -n 1)
            _dub_countdown=$(printf "%s" "$_page" | sed -nE 's|.*class="countdown-time countdown-time-dub" datetime="([^"]*)".*|\1|p' | head -n 1)

            [ -n "$_sub_ep" ] && [ -n "$_sub_countdown" ] &&
                printf "Next Sub: Episode %s in \033[1;%sm%s\033[0m\n" "$_sub_ep" "$_color" "$_sub_countdown" || printf "Next Sub: N/A\n"
            [ -n "$_dub_ep" ] && [ -n "$_dub_countdown" ] &&
                printf "Next Dub: Episode %s in \033[1;%sm%s\033[0m\n" "$_dub_ep" "$_color" "$_dub_countdown" || printf "Next Dub: N/A\n"
        fi
        printf "\n"
    done
    exit 0
}

# HISTORY

backup_old_hist() {
    backupfile="${histfile}.v4"
    : >"${histfile}.new"
    while IFS="	" read -r ep_no anime_id anime_title; do
        case "$anime_id" in
            *-*) printf "%s\t%s\t%s\n" "$ep_no" "$anime_id" "$anime_title" >>"${histfile}.new" ;;
            *) printf "%s\t%s\t%s\n" "$ep_no" "$anime_id" "$anime_title" >>"$backupfile" ;;
        esac
    done <"$histfile"
    mv "${histfile}.new" "$histfile"
}

process_hist_entry() {
    ep_list=$(hianime_episodes "$anime_id" | cut -f 2)
    ep_no=$(printf "%s" "$ep_list" | sed -n "/^${ep_no}$/{n;p;}") 2>/dev/null
    [ -n "$ep_no" ] && printf "%s\t%s - episode %s\n" "$anime_id" "$anime_title" "$ep_no"
}

update_history() {
    if grep -q "	${anime_id}	" "$histfile"; then
        # escape sed special chars in replacement: & and \ and delimiter |
        safe_title=$(printf "%s" "$anime_title" | sed 's|[&\|]|\\&|g')
        sed -E "s|^[^	]+	${anime_id}	[^	]+$|${ep_no}	${anime_id}	${safe_title}|" "$histfile" >"${histfile}.new"
    else
        cp "$histfile" "${histfile}.new"
        printf "%s\t%s\t%s\n" "$ep_no" "$anime_id" "$anime_title" >>"${histfile}.new"
    fi
    mv "${histfile}.new" "$histfile"
}

# PLAYING

# shellcheck disable=SC2086
# $1 = video link, $2 = video name, $3 = extra flags
download() {
    _name="$(printf "%s" "$2" | tr '<>:"/\\|?*' '_')"
    [ -n "$sub_link" ] && $curl_exe -sL -A "$agent" -e "$refr" --max-time 10 $cipher_flag "$sub_link" -o "$download_dir/$_name.vtt"
    [ -z "$audio_link" ] && command -v "yt-dlp" >/dev/null && yt-dlp --referer "$refr" "$1" --no-skip-unavailable-fragments --fragment-retries infinite -N 16 -P "$download_dir" -P "temp:$tmp_dir" -o "$_name.mp4" $3 && return 0
    ffmpeg -extension_picky 0 -referer "$refr" -loglevel error -stats -i "$1" ${audio_link:+-extension_picky 0 -referer "$refr" -i "$audio_link"} -c copy "$download_dir/$_name.mp4" $3
}

# mpv-android takes no options from the intent, so they go through a file the user includes in mpv.conf
# shellcheck disable=SC2086
android_mpv() {
    _conf_dir="/storage/emulated/0/mpv"
    if [ -w "${_conf_dir%/mpv}" ]; then
        [ -d "$_conf_dir" ] || mkdir "$_conf_dir"
        printf "referrer=%s\n%s\n%s\n" "$refr" "${sub_link:+sub-file=$sub_link}" "${audio_link:+audio-file=$audio_link}" >"$_conf_dir/mpv.config.mp4"
    fi
    nohup am start --user 0 -a android.intent.action.VIEW -d "$video_link" -n is.xyz.mpv/.MPVActivity -e "title" "${anime_title} Episode ${ep_no}" $player_extra_flags >/dev/null 2>&1 &
}

play_episode() {
    [ "$log_episode" = 1 ] && [ "$player_function" != "debug" ] && [ "$player_function" != "download" ] && command -v logger >/dev/null && logger -t ani-cli "${anime_title} ${ep_no}"
    [ -z "$video_link" ] && get_video_link
    [ "$skip_intro" = 1 ] && skip_flag="$(ani-skip -i "$mal_id" -e "$ep_no")"
    # wait for the previous player to close (in range selection)
    wait
    # shellcheck disable=SC2086
    case "$player_function" in
        debug) printf "All links:\n%s\nSelected link:\n%s\nAudio:\n%s\nSubtitles:\n%s\n" "$links" "$video_link" "$audio_link" "$sub_link" ;;
        android_mpv) android_mpv ;;
        android_vlc) nohup am start --user 0 -a android.intent.action.VIEW -d "$video_link" -n org.videolan.vlc/org.videolan.vlc.gui.video.VideoPlayerActivity -e "title" "${anime_title} Episode ${ep_no}" $player_extra_flags >/dev/null 2>&1 & ;;
        *flatpak*mpv*) flatpak run io.mpv.Mpv --referrer="$refr" ${audio_link:+--audio-file="$audio_link"} ${sub_link:+--sub-file="$sub_link"} $skip_flag $player_extra_flags --force-media-title="${anime_title} Episode ${ep_no}" "$video_link" >/dev/null 2>&1 & ;;
        *mpv*)
            if [ "$no_detach" = 0 ]; then
                nohup $player_function --referrer="$refr" ${audio_link:+--audio-file="$audio_link"} ${sub_link:+--sub-file="$sub_link"} $skip_flag $player_extra_flags --force-media-title="${anime_title} Episode ${ep_no}" "$video_link" >/dev/null 2>&1 &
            else
                $player_function --referrer="$refr" ${audio_link:+--audio-file="$audio_link"} ${sub_link:+--sub-file="$sub_link"} $skip_flag $player_extra_flags --force-media-title="${anime_title} Episode ${ep_no}" "$video_link"
                mpv_exitcode=$?
                [ "$exit_after_play" = 1 ] && [ -z "$_range" ] && exit "$mpv_exitcode"
            fi
            ;;
        *iina*)
            # mpv splits sub-files on ':', so the url has to be escaped for iina
            _sub_iina="$(printf "%s" "$sub_link" | sed 's|:|\\:|g')"
            _audio_iina="$(printf "%s" "$audio_link" | sed 's|:|\\:|g')"
            if pgrep -f "IINA" >/dev/null 2>&1; then
                # omit --keep-running when an IINA instance exists to prevent hanging
                nohup $player_function --mpv-referrer="$refr" ${_audio_iina:+--mpv-audio-files="$_audio_iina"} ${_sub_iina:+--mpv-sub-files="$_sub_iina"} $player_extra_flags --no-stdin --mpv-force-media-title="${anime_title} Episode ${ep_no}" "$video_link" >/dev/null 2>&1 &
            else
                nohup $player_function --mpv-referrer="$refr" ${_audio_iina:+--mpv-audio-files="$_audio_iina"} ${_sub_iina:+--mpv-sub-files="$_sub_iina"} $player_extra_flags --no-stdin --keep-running --mpv-force-media-title="${anime_title} Episode ${ep_no}" "$video_link" >/dev/null 2>&1 &
            fi
            ;;
        *vlc*) nohup $player_function --http-referrer="$refr" $player_extra_flags --play-and-exit --meta-title="${anime_title} Episode ${ep_no}" "$video_link" :input-slave="${audio_link:+$audio_link#}$sub_link" >/dev/null 2>&1 & ;;
        *yncpla*) nohup $player_function $player_extra_flags "$video_link" -- $skip_flag --referrer="$refr" ${audio_link:+--audio-file="$audio_link"} ${sub_link:+--sub-file="$sub_link"} --force-media-title="${anime_title} Episode ${ep_no}" >/dev/null 2>&1 & ;;
        download) "$player_function" "$video_link" "${anime_title} Episode ${ep_no}" $player_extra_flags ;;
        catt) nohup catt cast $player_extra_flags "$video_link" >/dev/null 2>&1 & ;;
        iSH)
            printf "\033]8;;vlc://%s\a~~~~~~~~~~~~~~~~~~~~\n~ Tap to open VLC ~\n~~~~~~~~~~~~~~~~~~~~\033]8;;\a\n" "$video_link"
            sleep 5
            ;;
        *) nohup $player_function $player_extra_flags "$video_link" >/dev/null 2>&1 & ;;
    esac
    replay="$video_link"
    unset video_link
    update_history
    [ "$menu_program" != "fzf" ] && wait
}

play() {
    _start=$(printf "%s" "$ep_no" | grep -Eo '^(-1|[0-9]+(\.[0-9]+)?)')
    _end=$(printf "%s" "$ep_no" | grep -Eo '(-1|[0-9]+(\.[0-9]+)?)$')
    [ "$_start" = "-1" ] && ep_no=$(printf "%s" "$ep_list" | tail -n 1) && unset _start
    [ -z "$_end" ] || [ "$_end" = "$_start" ] && unset _start _end
    [ "$_start" = "0" ] && _start=$(printf "%s" "$ep_list" | head -n 1)
    [ "$_end" = "-1" ] && _end=$(printf "%s" "$ep_list" | tail -n 1)
    _line_count=$(printf "%s\n" "$ep_no" | wc -l | tr -d "[:space:]")
    if [ "$_line_count" != 1 ] || [ -n "$_start" ]; then
        [ -z "$_start" ] && _start=$(printf "%s\n" "$ep_no" | head -n 1)
        [ -z "$_end" ] && _end=$(printf "%s\n" "$ep_no" | tail -n 1)
        _range=$(printf "%s\n" "$ep_list" | sed -nE "/^${_start}\$/,/^${_end}\$/p")
        [ -z "$_range" ] && die "Invalid range!"
        for i in $_range; do
            tput clear
            ep_no=$i
            info "Playing episode $ep_no..."
            [ "$i" = "$_end" ] && unset _range
            play_episode
        done
    else
        printf "%s" "$ep_list" | grep -q "^$ep_no$" || die "Invalid episode!"
        play_episode
    fi
    # moves up to stored position and deletes to end
    [ "$player_function" != "debug" ] && [ "$player_function" != "download" ] && tput rc && tput ed
}

# MAIN

# setup
base_api="https://hianime.at"
search_api="${base_api}/search?keyword=%s"
episodes_api="${base_api}/api/theme/episode/list/%s"
servers_api="${base_api}/api/theme/episode/servers?episodeId=%s"
ciphers='ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-CHACHA20-POLY1305:ECDHE-RSA-CHACHA20-POLY1305'
tls13_ciphers='TLS_AES_128_GCM_SHA256:TLS_AES_256_GCM_SHA384:TLS_CHACHA20_POLY1305_SHA256'
agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"

mode="${ANI_CLI_MODE:-sub}"
download_dir="${ANI_CLI_DOWNLOAD_DIR:-.}"
tmp_dir="${ANI_CLI_TMP_DIR:-.}"
log_episode="${ANI_CLI_LOG:-1}"
quality="${ANI_CLI_QUALITY:-best}"
exact_match="${ANI_CLI_EXACT:-0}"

curl_exe=$(dep_ch_failover "curl_firefox135,curl_chrome136,curl_chrome116,curl_ff117,curl") || die "Program curl not found"

case "$(uname -a | cut -d " " -f 1,3-)" in
    *Darwin*)
        cipher_flag="--ciphers $ciphers --tls13-ciphers $tls13_ciphers"
        player_function="${ANI_CLI_PLAYER:-$(dep_ch_failover "iina,/Applications/IINA.app/Contents/MacOS/iina-cli,mpv,vlc")}" || die 'No player found. Looked for iina, mpv and vlc'
        ;;                                                            # mac OS
    *ndroid*) player_function="${ANI_CLI_PLAYER:-android_mpv}" ;;     # Android OS (termux)
    *MINGW* | *WSL2*) player_function="${ANI_CLI_PLAYER:-mpv.exe}" ;; # Windows OS
    *ish*)
        player_function="${ANI_CLI_PLAYER:-iSH}"
        curl_exe=$(dep_ch_failover "curl_safari260_ios,$curl_exe")
        ;;                                                                                                                                                                                               # iOS (iSH)
    *) player_function="${ANI_CLI_PLAYER:-$(dep_ch_failover "mpv,$HOME/.local/share/flatpak/app/io.mpv.Mpv/,/var/lib/flatpak/app/io.mpv.Mpv/,vlc")}" || die 'No player found. Looked for mpv and vlc' ;; # Linux OS
esac

player_extra_flags="${ANI_CLI_PLAYER_FLAGS:-""}"
no_detach="${ANI_CLI_NO_DETACH:-0}"
exit_after_play="${ANI_CLI_EXIT_AFTER_PLAY:-0}"
skip_intro="${ANI_CLI_SKIP_INTRO:-0}"
menu_program="${ANI_CLI_MENU:-fzf}"
menu_extra_flags="${ANI_CLI_MENU_FLAGS:-""}"

# not opening from a terminal
if [ ! -t 0 ]; then
    command -v dmenu >/dev/null && menu_program=dmenu
    command -v rofi >/dev/null && menu_program=rofi
fi

hist_dir="${ANI_CLI_HIST_DIR:-${XDG_STATE_HOME:-$HOME/.local/state}/ani-cli}"
[ ! -d "$hist_dir" ] && mkdir -p "$hist_dir"
histfile="$hist_dir/ani-hsts"
[ ! -f "$histfile" ] && : >"$histfile"

source="${ANI_CLI_DEFAULT_SOURCE:-search}"
branch="${ANI_CLI_BRANCH:-master}"

