#!/bin/sh
# Moves your old data (downloads, photos) from ~/ani-gui into ~/ani/storage. Safe to run again any time.
OLD="$HOME/ani-gui"; NEW="$HOME/ani/storage"
mkdir -p "$NEW/downloads" "$NEW/cache" "$NEW/data" "$HOME/ani/public"
pkill -f "node server.js" 2>/dev/null; sleep 1
for d in downloads cache; do
  if [ -d "$OLD/$d" ]; then
    for f in "$OLD/$d"/*; do
      [ -e "$f" ] || continue
      b=$(basename "$f")
      [ -e "$NEW/$d/$b" ] || mv "$f" "$NEW/$d/$b"
    done
    rmdir "$OLD/$d" 2>/dev/null
  fi
done
[ -f "$OLD/hls.min.js" ] && [ ! -f "$HOME/ani/public/hls.min.js" ] && cp "$OLD/hls.min.js" "$HOME/ani/public/hls.min.js"
echo "Done. Your data is now in $NEW"
du -sh "$NEW"/* 2>/dev/null
