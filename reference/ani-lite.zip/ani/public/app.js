'use strict';
/* ===================================================== ani ===================================================== */
const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const p2=n=>String(n).padStart(2,'0');
const fmtT=t=>{t=Math.max(0,t|0);const h=t/3600|0,m=(t%3600)/60|0,s=t%60;return(h?h+':'+p2(m):p2(m))+':'+p2(s)};
const bytes=n=>n>=1e9?(n/1e9).toFixed(2)+' GB':n>=1e6?(n/1e6).toFixed(1)+' MB':Math.max(0,n/1e3|0)+' KB';
const ic=(n,c='')=>`<svg class="ic ${c}"><use href="#i-${n}"/></svg>`;
const api=(p,o)=>fetch(p,o).then(r=>r.json());
const post=(p,b)=>api(p,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(b)}).catch(()=>({error:'Offline or server stopped'}));
const pic=u=>u?'/img?url='+encodeURIComponent(u):'';
const px=(u,r)=>'/proxy?url='+encodeURIComponent(u)+'&ref='+encodeURIComponent(r||'https://hianime.at/');
const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
addEventListener('error',e=>{const b=$('#err');b.style.display='block';b.textContent=(e.message||'error')+' @'+String(e.filename||'').split('/').pop()+':'+e.lineno});
document.addEventListener('load',e=>{if(e.target.tagName==='IMG')e.target.classList.add('ld')},true);

/* ---------- storage: localStorage for speed, mirrored to the server's storage/data folder so updates never lose it ---------- */
const KEYS=['mode','hist','pf','rq','ra','list','G'];
const dirty=new Set();let pT=0;
const S={get(k,d){try{const v=localStorage.getItem('ani.'+k);return v==null?d:JSON.parse(v)}catch{return d}},
  set(k,x){try{localStorage.setItem('ani.'+k,JSON.stringify(x))}catch{}if(KEYS.includes(k)){dirty.add(k);clearTimeout(pT);pT=setTimeout(push,k==='hist'?5000:900)}},
  loc(k,d){try{return localStorage.getItem('ani.l.'+k)||d}catch{return d}},setLoc(k,v){try{localStorage.setItem('ani.l.'+k,v)}catch{}}};
function push(){if(!dirty.size)return;const o={};dirty.forEach(k=>o[k]=localStorage.getItem('ani.'+k));dirty.clear();
  fetch('/api/state',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(o)}).catch(()=>{})}
async function pull(){
  const st=await fetch('/api/state').then(r=>r.json()).catch(()=>null);if(!st)return;
  for(const k of KEYS){if(st[k]!=null)try{localStorage.setItem('ani.'+k,st[k])}catch{}else if(localStorage.getItem('ani.'+k)!=null)dirty.add(k)}
  if(dirty.size)push();
}
function importOld(){            // history from the very first version of the app
  try{if(localStorage.getItem('ani.hist')!=null)return;const old=JSON.parse(localStorage.getItem('hist')||'null');if(!old)return;
    const h={},g={};for(const o of Object.values(old)){g[o.id]={key:o.id,name:o.name,thumb:o.thumb||'',seasons:[{id:o.id,name:o.name,thumb:o.thumb||'',kind:'season',num:1,part:0,label:'Season 1'}]};
      h[o.id]={gk:o.id,sid:o.id,ep:o.ep,pos:o.pos,dur:o.dur,t:o.t,w:{[o.ep]:[o.pos,o.dur]}}}
    localStorage.setItem('ani.hist',JSON.stringify(h));localStorage.setItem('ani.G',JSON.stringify(g));dirty.add('hist');dirty.add('G')}catch{}
}

/* ---------- state ---------- */
let mode,hist,pf,G,list,recentQ,recentA,tab='home';
const GR={},INFO={};                     // search results (by group key), cinemeta info
let cg=null,cs=null,cure='',eps=[],epsKey='',epLimit=20;
let dlItems=[],dlMeta={used:0,free:0};
const EPC={};                            // episode lists cache
function loadState(){
  mode=S.get('mode','sub');hist=S.get('hist',{});G=S.get('G',{});list=S.get('list',[]);recentQ=S.get('rq',[]);recentA=S.get('ra',[]);
  pf=Object.assign({ss:26,sp:1,dq:'best',sl:'English',langs:['ara'],sd:0},S.get('pf',{}));
  document.documentElement.style.setProperty('--ss',pf.ss+'px');
}
const v=$('#v'),pl=$('#player');
const LN={ara:'Arabic',eng:'English',fre:'French',spa:'Spanish',por:'Portuguese',pob:'Portuguese (Brazil)',ger:'German',ita:'Italian',rus:'Russian',tur:'Turkish',ind:'Indonesian',vie:'Vietnamese',tha:'Thai',pol:'Polish',hin:'Hindi',kor:'Korean',jpn:'Japanese',zht:'Chinese (Trad.)',zhc:'Chinese (Simp.)'};

/* ---------- layered back gesture ---------- */
const layers=[];
function openLayer(name,fn){if(layers.some(l=>l.name===name))return;history.pushState({l:name},'');layers.push({name,fn})}
addEventListener('popstate',()=>{const l=layers.pop();if(l)l.fn()});
let tT;function toast(t){const e=$('#toast');e.textContent=t;e.classList.add('show');clearTimeout(tT);tT=setTimeout(()=>e.classList.remove('show'),2000)}
function net(){document.body.classList.toggle('offline',!navigator.onLine)}
addEventListener('online',()=>{net();toast('Back online')});addEventListener('offline',()=>{net();toast('You are offline')});net();

/* ---------- always fullscreen: the first touch after launch enters it silently ---------- */
function goFs(){if(document.fullscreenElement)return;const r=document.documentElement;
  try{const p=r.requestFullscreen&&r.requestFullscreen({navigationUI:'hide'});p&&p.catch&&p.catch(()=>{})}catch{}}
addEventListener('pointerup',goFs,true);addEventListener('click',goFs,true);addEventListener('keydown',goFs,true);goFs();
document.addEventListener('fullscreenchange',()=>{if(!document.fullscreenElement)setTimeout(()=>{},0)});

/* ---------- cards & lists ---------- */
const seasonWord=g=>{const n=new Set(g.seasons.filter(s=>s.kind==='season').map(s=>s.fin?'f':s.num)).size,o=g.seasons.filter(s=>s.kind!=='season').length;return n>1?n+' seasons':n===1&&o?'+ '+o+' more':''};
function gcard(g,i,sub){GR[g.key]=g;const sw=sub||seasonWord(g);
  return `<div class="card" data-g="${esc(g.key)}" style="--i:${Math.min(i,12)}"><div class="po"><img loading="lazy" src="${pic(g.thumb)}" alt="">${sw&&!sub?`<span class="tag">${esc(sw)}</span>`:''}</div><div class="ct">${esc(g.name)}</div>${sub?`<div class="cs">${esc(sub)}</div>`:''}</div>`}
const skel=n=>Array.from({length:n},()=>'<div class="card sk"><div class="po"></div><div class="ct"></div></div>').join('');
const gOf=k=>GR[k]||G[k];
const sOf=(g,id)=>g&&g.seasons.find(s=>s.id===id);
const addQ=q=>{q=(q||'').trim();if(!q)return;recentQ=[q,...recentQ.filter(x=>x.toLowerCase()!==q.toLowerCase())].slice(0,10);S.set('rq',recentQ)};
function addRecent(g){G[g.key]=g;recentA=[g.key,...recentA.filter(x=>x!==g.key)].slice(0,24);
  const keep=new Set([...recentA,...list,...Object.values(hist).map(h=>h.gk)]);for(const k of Object.keys(G))if(!keep.has(k))delete G[k];
  S.set('ra',recentA);S.set('G',G)}
function lastHist(g){let b=null;for(const s of g.seasons){const h=hist[s.id];if(h&&(!b||h.t>b.t))b=h}return b}
const done=h=>h&&h.dur&&h.pos>h.dur-35;

/* ---------- tabs ---------- */
function setTab(t){
  tab=t;S.setLoc('tab',t);
  $$('.tab').forEach(e=>e.classList.toggle('on',e.id==='tab-'+t));
  $$('#nav button').forEach(b=>b.classList.toggle('on',b.dataset.t===t));
  $('#hd').classList.toggle('search',t==='search');
  $('#blogo').style.display=t==='home'?'':'none';
  $('#htitle').style.display=t==='home'?'none':'';$('#htitle').textContent={dl:'Downloads',set:'Settings'}[t]||'';
  if(t==='home')renderHome();if(t==='search'){showSearchState();setTimeout(()=>{},0)}
  if(t==='dl'){renderDL();refreshDL()}if(t==='set')renderSettings();
  scrollTo(0,0);
}
/* home */
function renderHome(){
  const cont=Object.values(hist).filter(h=>gOf(h.gk)).sort((a,b)=>b.t-a.t).slice(0,12);
  let h='';
  if(cont.length)h+=`<h2>Continue watching</h2><div class="hrow">`+cont.map((x,i)=>{const g=gOf(x.gk),s=sOf(g,x.sid)||{label:''};
    const sub=`${g.seasons.length>1&&s.label?s.label+' · ':''}Ep ${x.ep}`;
    return `<div class="card" data-cont="${esc(x.sid)}" style="--i:${i}"><div class="po"><img src="${pic(g.thumb)}" alt=""><span class="tag">${done(x)?'Next':fmtT(x.pos)}</span><i class="lp" style="position:absolute;left:0;right:0;bottom:0;border-radius:0;margin:0;height:4px"><u style="width:${x.dur?Math.min(100,x.pos/x.dur*100|0):0}%"></u></i></div><div class="ct">${esc(g.name)}</div><div class="cs">${esc(sub)}</div></div>`}).join('')+`</div>`;
  const L=list.map(gOf).filter(Boolean);
  if(L.length)h+=`<h2>My list</h2><div class="hrow">`+L.map((g,i)=>gcard(g,i)).join('')+`</div>`;
  const R=recentA.map(gOf).filter(g=>g&&!list.includes(g.key));
  if(R.length)h+=`<h2>Recently viewed <a data-clra>Clear</a></h2><div class="hrow">`+R.map((g,i)=>gcard(g,i)).join('')+`</div>`;
  $('#home').innerHTML=h||`<div class="empty"><img src="/logo.svg" width="130" alt=""><p>Search for an anime to begin</p></div>`;
}
/* search */
function showSearchState(){
  const q=$('#q').value.trim();
  $('#recent').style.display=q?'none':'';$('#rt').style.display=q?'':'none';$('#res').style.display=q?'':'none';
  if(!q){$('#res').innerHTML='';
    $('#recent').innerHTML=recentQ.length?`<h2>Recent searches <a data-clrq>Clear</a></h2><div class="chips">`+recentQ.map(x=>`<span class="chip" data-sq="${esc(x)}">${esc(x)}<b data-dq="${esc(x)}">${ic('x')}</b></span>`).join('')+`</div>`:`<div class="empty">${ic('search')}<p>Find any anime</p></div>`}
}
let sT,sSeq=0;
async function search(){
  const q=$('#q').value.trim();showSearchState();if(!q)return;
  const my=++sSeq,box=$('#res');$('#rt').textContent='Searching…';box.innerHTML=skel(9);
  const d=await api('/api/search?q='+encodeURIComponent(q)).catch(()=>({error:'Offline or server stopped',groups:[]}));
  if(my!==sSeq)return;
  const gs=d.groups||[];$('#rt').textContent=d.error?'Error: '+d.error:(gs.length?'Results':'No results');
  box.innerHTML=gs.map((g,i)=>gcard(g,i)).join('');
}
$('#q').addEventListener('input',()=>{clearTimeout(sT);sT=setTimeout(search,450);if(!$('#q').value.trim())showSearchState()});
$('#q').addEventListener('keydown',e=>{if(e.key==='Enter'){clearTimeout(sT);addQ($('#q').value);search();$('#q').blur()}});
function setMode(m){mode=m;S.set('mode',m);$$('#seg button,#seg2 button').forEach(b=>b.classList.toggle('on',b.dataset.m===m))}
async function modeClick(m){if(m===mode)return;setMode(m);if($('#show').classList.contains('open')&&cs){$('#eps').innerHTML='';await selectSeason(cs,true)}}
$('#seg').onclick=e=>{const m=e.target.dataset.m;if(m)modeClick(m)};$('#seg2').onclick=e=>{const m=e.target.dataset.m;if(m)modeClick(m)};

/* ---------- settings ---------- */
function renderSettings(){
  const L=['ara','eng','fre','spa','por','pob','ger','ita','rus','tur','ind','vie','tha','pol','hin'];
  $('#settings').innerHTML=`
  <h2>Playback</h2><div class="set">
   <div class="row"><span>Default subtitles</span><select id="sSl">${['English','Arabic','Off'].map(x=>`<option ${pf.sl===x?'selected':''}>${x}</option>`).join('')}</select></div>
   <div class="row"><span>Subtitle size</span><input type="range" id="sSs" min="14" max="64" value="${pf.ss}"></div></div>
  <h2>Downloads</h2><div class="set">
   <div class="row"><span>Default quality</span><select id="sDq">${[['best','Best'],['1080','1080p'],['720','720p'],['540','540p'],['360','360p']].map(([k,n])=>`<option value="${k}" ${pf.dq===k?'selected':''}>${n}</option>`).join('')}</select></div>
   <div style="padding:12px 0 4px">Extra subtitle languages to pre-select<div class="mut" style="font-size:12px;margin:3px 0 10px">Found online when you download an episode</div><div class="langs" id="sLg">${L.map(c=>`<button class="lg ${pf.langs.includes(c)?'on':''}" data-lg="${c}">${LN[c]}</button>`).join('')}</div></div></div>
  <h2>Storage</h2><div class="set">
   <div class="row"><span>Downloaded episodes</span><span class="mut">${bytes(dlMeta.used)}</span></div>
   <div class="row"><span>Free space</span><span class="mut">${dlMeta.free?bytes(dlMeta.free):'…'}</span></div>
   <div class="row"><span>Image cache</span><button class="btn ghost" id="sCc" style="padding:8px 16px;font-size:13px">Clear</button></div>
   <div class="about">Downloads, cached photos, your history and settings all live in the <b>storage</b> folder, so updating ani never touches them.</div></div>
  <h2>About</h2><div class="set"><div class="about"><b style="color:var(--tx)">ani</b> 2.0<br>For instant fullscreen on launch: Chrome menu → <i>Add to Home screen</i> / <i>Install app</i>, then open ani from your home screen.</div></div>`;
}
document.addEventListener('change',e=>{const t=e.target;
  if(t.id==='sSl'){pf.sl=t.value;S.set('pf',pf)}
  if(t.id==='sDq'){pf.dq=t.value;S.set('pf',pf)}});
document.addEventListener('input',e=>{if(e.target.id==='sSs'){pf.ss=+e.target.value;document.documentElement.style.setProperty('--ss',pf.ss+'px');S.set('pf',pf)}});

/* ---------- show page ---------- */
const ST={queued:1,preparing:1,downloading:1};
const dlFor=(sid,ep,m)=>dlItems.find(x=>x.id===sid&&String(x.ep)===String(ep)&&x.mode===m);
const downloadedEps=(sid,m)=>dlItems.filter(x=>x.id===sid&&x.mode===m&&x.done>0).map(x=>x.ep).sort((a,b)=>parseFloat(a)-parseFloat(b));
async function loadEps(s,force){
  const k=s.id+mode;if(!force&&EPC[k])return EPC[k];
  const d=await api(`/api/episodes?id=${encodeURIComponent(s.id)}&mode=${mode}`).catch(()=>null);
  const l=d&&d.eps&&d.eps.length?d.eps:downloadedEps(s.id,mode);
  if(d&&d.eps&&d.eps.length)EPC[k]=l;return l;
}
async function openShow(g,sid){
  addRecent(g);cg=g;
  const lh=lastHist(g);
  const s=(sid&&sOf(g,sid))||(lh&&sOf(g,lh.sid))||g.seasons.find(x=>x.kind==='season')||g.seasons[0];
  $('#sname').textContent=g.name;$('#stitle').textContent=g.name;
  setHero(g.thumb);$('#smeta').innerHTML=seasonWord(g)?`<span>${seasonWord(g)}</span>`:'';$('#desc').textContent='';$('#more').style.display='none';
  $('#sheart').classList.toggle('on',list.includes(g.key));$('#slater').classList.toggle('on',list.includes(g.key));
  $('#slater span').textContent=list.includes(g.key)?'In my list':'Watch later';
  $('#show').scrollTop=0;$('#sbar').classList.remove('solid');
  $('#show').classList.add('open');openLayer('show',()=>{$('#show').classList.remove('open')});
  paintWatch();
  selectSeason(s);
  loadInfo(g);
}
function setHero(u){const im=$('#himg');im.classList.remove('ld');im.src=u?pic(u):''}
async function loadInfo(g){
  let d=INFO[g.key];
  if(d===undefined){d=await api('/api/info?title='+encodeURIComponent(g.name)).catch(()=>({}));INFO[g.key]=d}
  if(cg!==g||!d||!d.id)return;
  const bits=[];if(d.rating)bits.push(`<span class="imdb">IMDb</span><b>${esc(d.rating)}</b>`);if(d.year)bits.push(esc(String(d.year).slice(0,9)));
  if(d.genres&&d.genres.length)bits.push(esc(d.genres.slice(0,3).join(' · ')));
  const sw=seasonWord(g);if(sw)bits.push(sw);
  $('#smeta').innerHTML=bits.map(x=>`<span>${x}</span>`).join('');
  if(d.desc){$('#desc').textContent=d.desc;$('#desc').classList.remove('full');$('#more').style.display=d.desc.length>150?'inline':'none';$('#more').textContent='More'}
  if(d.bg)setHero(d.bg);
  if(cs)paintEps(true);
}
$('#more').onclick=()=>{const f=$('#desc').classList.toggle('full');$('#more').textContent=f?'Less':'More'};
$('#show').addEventListener('scroll',()=>$('#sbar').classList.toggle('solid',$('#show').scrollTop>230),{passive:true});
$('#sback').onclick=()=>history.back();
function toggleList(){if(!cg)return;const i=list.indexOf(cg.key);if(i>=0)list.splice(i,1);else list.unshift(cg.key);S.set('list',list);
  const on=list.includes(cg.key);$('#sheart').classList.toggle('on',on);$('#slater').classList.toggle('on',on);$('#slater span').textContent=on?'In my list':'Watch later';toast(on?'Added to my list':'Removed from my list')}
$('#sheart').onclick=toggleList;$('#slater').onclick=toggleList;
function renderSeasons(){
  let h='',prev=null;
  for(const s of cg.seasons){const k=s.kind==='season'?0:1;if(prev!==null&&k!==prev)h+='<span class="sep"></span>';prev=k;
    h+=`<button data-sid="${esc(s.id)}" class="${cs&&cs.id===s.id?'on':''}">${esc(s.label)}</button>`}
  $('#seasons').innerHTML=cg.seasons.length>1?h:'';$('#seasons').style.display=cg.seasons.length>1?'':'none';
  const on=$('#seasons .on');if(on)on.scrollIntoView({inline:'center',block:'nearest'});
}
async function selectSeason(s,force){
  cs=s;renderSeasons();epLimit=20;
  $('#eps').innerHTML='<div class="empty" style="padding:40px 0"><div class="spin"></div></div>';$('#moreb').style.display='none';
  const my=s,l=await loadEps(s,force);if(cs!==my)return;
  eps=l;epsKey=s.id+mode;
  const h=hist[s.id],i=h?eps.indexOf(String(h.ep)):-1;if(i>=epLimit-3)epLimit=i+8;
  paintEps(true);paintWatch();
}
$('#seasons').onclick=e=>{const b=e.target.closest('button');if(!b||(cs&&b.dataset.sid===cs.id))return;selectSeason(sOf(cg,b.dataset.sid))};
function epMeta(n){                      // IMDb title/thumbnail, only trusted when the episode counts match
  const d=INFO[cg&&cg.key];if(!d||!d.eps||!cs||cs.kind!=='season')return null;
  const sn=cs.num,m=d.eps[sn];if(!m)return null;
  if(cg.seasons.filter(x=>x.kind==='season'&&x.num===cs.num).length>1)return null;
  if(Object.keys(m).length!==eps.length)return null;return m[Math.round(parseFloat(n))]||null;
}
function dlBtn(it){
  const C=119.4,s=it?it.state:'',p=s==='done'?1:it?(ST[s]&&!it.pct?.25:it.pct/100):0;
  const icon=s==='done'?'check':s==='error'?'alert':s==='paused'?'pause':'download';
  return `<button class="dlb" data-dl data-s="${s}" aria-label="Download options">${it&&s!=='done'?`<svg class="ring" viewBox="0 0 42 42"><circle class="bg" cx="21" cy="21" r="19"/><circle class="fg" cx="21" cy="21" r="19" stroke-dasharray="${C}" stroke-dashoffset="${C*(1-p)}"/></svg>`:''}${ic(icon,icon==='pause'?'fill':'')}</button>`;
}
function paintEps(rebuild){
  const box=$('#eps');if(!cs)return;
  const sig=cs.id+mode+eps.length+epLimit+(INFO[cg.key]?1:0);
  if(rebuild||box.dataset.sig!==sig){
    box.dataset.sig=sig;
    const show=eps.slice(0,epLimit),h=hist[cs.id],sub=esc(cg.name+(cg.seasons.length>1?' · '+cs.label:''));
    box.innerHTML=show.map((e,i)=>{const m=epMeta(e),w=h&&h.w&&h.w[e],watched=w&&w[1]&&w[0]>w[1]-35,pr=w&&w[1]?Math.min(100,w[0]/w[1]*100|0):0,it=dlFor(cs.id,e,mode);
      return `<div class="er ${h&&String(h.ep)===e?'cur':''}" data-ep="${esc(e)}" style="--i:${Math.min(i,14)}"><div class="th" data-play><img loading="lazy" src="${pic(m&&m.th||cs.thumb||cg.thumb)}" alt="">${watched?`<span class="eye">${ic('eye')}</span>`:`<span class="play"><svg class="ic fill" style="width:30px;height:30px;opacity:.9"><use href="#i-play"/></svg></span>`}${pr&&!watched?`<i class="pb" style="width:${pr}%"></i>`:''}</div>
      <div class="tt" data-play><small>${sub}</small><b>${m&&m.t?esc(Math.round(parseFloat(e))+'. '+m.t):'Episode '+esc(e)}</b>${w&&w[1]?`<i>${watched?'Watched':Math.round((w[1]-w[0])/60)+' min left'}</i>`:it&&it.duration?`<i>${Math.round(it.duration/60)} min</i>`:''}</div>${dlBtn(it)}</div>`}).join('')||`<div class="empty" style="padding:40px 0"><p>No episodes for ${mode==='dub'?'dub':'sub'}</p></div>`;
    const more=eps.length-epLimit;$('#moreb').style.display=more>0?'':'none';$('#moreb').textContent=`Show all (${eps.length} episodes)`;
  }else{
    box.querySelectorAll('.er').forEach(r=>{const it=dlFor(cs.id,r.dataset.ep,mode),b=r.querySelector('.dlb'),tmp=document.createElement('div');tmp.innerHTML=dlBtn(it);
      const n=tmp.firstElementChild;if(b.dataset.s!==n.dataset.s||(it&&ST[it.state]||it&&it.state==='paused')){b.replaceWith(n)}});
  }
}
$('#moreb').onclick=()=>{epLimit=eps.length;paintEps(true)};
function paintWatch(){
  if(!cg)return;const h=lastHist(cg);let t='Watch now';
  if(h){const s=sOf(cg,h.sid),sl=cg.seasons.length>1&&s?'S'+(s.kind==='season'?s.num:'')+' ':'';t=done(h)?'Next episode':'Continue · '+(s&&cg.seasons.length>1?s.label+' · ':'')+'Ep '+h.ep}
  $('#wtxt').textContent=t;
}
$('#watch').onclick=async()=>{
  const h=lastHist(cg);
  if(h){const s=sOf(cg,h.sid);let l=s.id===(cs&&cs.id)?eps:await loadEps(s);
    if(done(h)){const i=l.indexOf(String(h.ep))+1;if(l[i])return play(cg,s,l[i]);const ns=cg.seasons[cg.seasons.indexOf(s)+1];if(ns){const nl=await loadEps(ns);if(nl[0])return play(cg,ns,nl[0])}toast('You are all caught up');return}
    return play(cg,s,h.ep)}
  if(eps[0])play(cg,cs,eps[0]);else toast('No episodes yet');
};

/* ---------- download sheet ---------- */
let dctx=null;
function sheetOpen(){const sh=$('#dsheet');sh.classList.add('open');openLayer('dsheet',()=>sh.classList.remove('open'))}
$('#dsheet').addEventListener('click',e=>{if(e.target.id==='dsheet')history.back()});
function subParams(ep){
  const same=cg.seasons.filter(x=>x.kind==='season'&&x.num===cs.num&&x.part<cs.part).sort((a,b)=>a.part-b.part).map(x=>x.id);
  return`title=${encodeURIComponent(cg.name)}&season=${cs.kind==='season'?cs.num:''}&ep=${encodeURIComponent(ep||'')}&count=${eps.length}&offsetIds=${encodeURIComponent(same.join(','))}`;
}
const QN=[['best','Best'],['1080','1080p'],['720','720p'],['540','540p'],['360','360p']];
function openDl(ep){
  const it=ep!=null?dlFor(cs.id,ep,mode):null;
  dctx={ep,q:pf.dq,picked:new Set(pf.langs),found:null};
  const sub=`${esc(cg.name)}${cg.seasons.length>1?' · '+esc(cs.label):''} · ${mode==='dub'?'Dub':'Sub'}`;
  if(it){renderDlStatus(it,sub)}else{
    $('#dpanel').innerHTML=`<div class="grab"></div><h3>${ep!=null?'Download episode '+esc(ep):'Download all '+eps.length+' episodes'}</h3><p class="sub">${sub}</p>
    <h4>Quality</h4><div class="qs" id="dq">${QN.map(([k,n])=>`<button class="lg ${dctx.q===k?'on':''}" data-q="${k}">${n}</button>`).join('')}</div>
    <h4>Subtitles</h4><p class="note">The built-in subtitles are always included.</p><div id="dsubs"></div>
    <div class="srow"><button class="btn ghost" data-close>Cancel</button><button class="btn" data-go>${ic('download')}Download</button></div>`;
    loadSubOptions(ep,'#dsubs');
  }
  sheetOpen();
}
async function loadSubOptions(ep,sel){
  const box=$(sel);
  if(cs.type||cs.kind!=='season'&&ep!=null&&false){box.innerHTML='<p class="note">Extra subtitles are not available for movies and specials.</p>';return}
  if(ep==null){      // whole season: languages are searched per episode as each download starts
    const L=[...new Set([...pf.langs,'ara','eng','fre','spa','por','pob','ger','ita','rus','tur','ind'])];
    box.innerHTML=`<div class="langs">${L.map(c=>`<button class="lg ${dctx.picked.has(c)?'on':''}" data-lg2="${c}">${LN[c]||c}</button>`).join('')}</div><p class="note">Searched for each episode when its download starts.</p>`;return}
  box.innerHTML='<p class="note"><span class="spin sm"></span>Looking for more subtitle languages…</p>';
  const d=await api('/api/subs/find?'+subParams(ep)).catch(()=>({subs:[],reason:'Could not reach the subtitle service'}));
  if(!dctx||dctx.ep!==ep||!$(sel))return;
  dctx.found=d.subs||[];
  if(!dctx.found.length){$(sel).innerHTML=`<p class="note">${esc(d.reason||'No extra subtitles found for this episode.')}</p>`;return}
  $(sel).innerHTML=dctx.found.map(s=>`<div class="sl ${dctx.picked.has(s.lang)?'on':''}" data-lg="${esc(s.lang)}"><span class="ck">${ic('check')}</span><span>${esc(s.label)}</span><small>${s.count} file${s.count>1?'s':''}</small></div>`).join('');
}
function renderDlStatus(it,sub){
  const st=stText(it);
  $('#dpanel').innerHTML=`<div class="grab"></div><h3>Episode ${esc(it.ep)}</h3><p class="sub">${sub}${it.h?' · '+it.h+'p':''}</p>
  <div class="note" style="margin-bottom:6px">${esc(st)}</div>${it.state!=='done'?`<i class="lp"><u style="width:${it.pct}%"></u></i>`:''}
  ${it.subs&&it.subs.length?`<h4>Subtitles saved</h4><div class="chips">${it.subs.map(t=>`<span class="lg on">${esc(t.label)}</span>`).join('')}</div>`:''}
  <div class="srow" style="flex-wrap:wrap">${it.state==='done'||it.done>0?`<button class="btn" data-playdl="${esc(it.key)}">${ic('play','fill')}Play</button>`:''}
  ${it.state==='done'?'':`<button class="btn ghost" data-pp="${esc(it.key)}">${ST[it.state]?'Pause':'Resume'}</button>`}
  <button class="btn ghost" data-rm="${esc(it.key)}">${ic('trash')}Delete</button></div>
  ${it.state==='done'?`<h4>Add subtitles</h4><div id="dsubs"></div><div class="srow"><button class="btn ghost" data-addsub>Add selected</button></div>`:''}`;
  if(it.state==='done'&&dctx&&dctx.ep!=null)loadSubOptions(dctx.ep,'#dsubs');
}
$('#dpanel').addEventListener('click',async e=>{
  const t=e.target;let x;
  if(t.closest('[data-close]'))return history.back();
  if(x=t.closest('[data-q]')){dctx.q=x.dataset.q;$$('#dq .lg').forEach(b=>b.classList.toggle('on',b===x));return}
  if(x=t.closest('[data-lg]')){const l=x.dataset.lg;dctx.picked.has(l)?dctx.picked.delete(l):dctx.picked.add(l);x.classList.toggle('on',dctx.picked.has(l));return}
  if(x=t.closest('[data-lg2]')){const l=x.dataset.lg2;dctx.picked.has(l)?dctx.picked.delete(l):dctx.picked.add(l);x.classList.toggle('on',dctx.picked.has(l));return}
  if(t.closest('[data-go]'))return startDl();
  if(t.closest('[data-addsub]')){const it=dlFor(cs.id,dctx.ep,mode);const subs=(dctx.found||[]).filter(s=>dctx.picked.has(s.lang)).map(s=>({lang:s.lang,label:s.label,url:s.url}));
    if(!subs.length)return toast('Pick a language first');await post('/api/dl/start',{id:cs.id,name:cg.name,label:cs.label,thumb:cs.thumb||cg.thumb,eps:[dctx.ep],mode,q:it.q,subs});toast('Adding subtitles…');history.back();return}
  if(x=t.closest('[data-playdl]')){const it=dlItems.find(i=>i.key===x.dataset.playdl);history.back();setTimeout(()=>it&&playLocal(it),260);return}
  if(x=t.closest('[data-pp]')){const it=dlItems.find(i=>i.key===x.dataset.pp);await post('/api/dl/'+(ST[it.state]?'pause':'resume'),{key:it.key});await refreshDL();return history.back()}
  if(x=t.closest('[data-rm]')){if(x.dataset.arm){await post('/api/dl/remove',{key:x.dataset.rm});toast('Deleted');await refreshDL();return history.back()}
    x.dataset.arm=1;x.innerHTML=ic('trash')+'Tap again';setTimeout(()=>{if(x.isConnected){delete x.dataset.arm;x.innerHTML=ic('trash')+'Delete'}},3000);return}
});
async function startDl(){
  const c=dctx;pf.dq=c.q;S.set('pf',pf);
  const base={id:cs.id,name:cg.name,label:cs.label,thumb:cs.thumb||cg.thumb,mode,q:c.q};
  let r;
  if(c.ep!=null){const subs=(c.found||[]).filter(s=>c.picked.has(s.lang)).map(s=>({lang:s.lang,label:s.label,url:s.url}));
    r=await post('/api/dl/start',{...base,eps:[c.ep],subs});toast(r.error||`Downloading episode ${c.ep}`)}
  else{const todo=eps.filter(e=>{const d=dlFor(cs.id,e,mode);return!d||d.state!=='done'});
    if(!todo.length){toast('Everything is already downloaded');return history.back()}
    const same=cg.seasons.filter(x=>x.kind==='season'&&x.num===cs.num&&x.part<cs.part).sort((a,b)=>a.part-b.part).map(x=>x.id);
    r=await post('/api/dl/start',{...base,eps:todo,subLangs:[...c.picked],title:cg.name,season:cs.kind==='season'?cs.num:'',count:eps.length,offsetIds:same});
    toast(r.error||`Queued ${todo.length} episodes`)}
  history.back();refreshDL();
}
$('#sall').onclick=()=>eps.length?openDl(null):toast('No episodes yet');

/* ---------- downloads ---------- */
const fmtEta=s=>s>=3600?(s/3600|0)+'h '+((s%3600)/60|0)+'m':s>=60?(s/60|0)+'m '+(s%60)+'s':s+'s';
function stText(it){
  switch(it.state){
    case'done':return `Downloaded · ${bytes(it.bytes)}`;
    case'error':return `Failed: ${it.err||'error'} · tap resume`;
    case'paused':return `Paused · ${it.pct}% · ${bytes(it.bytes)}`;
    case'queued':return 'Queued';
    case'preparing':return 'Preparing…';
  }
  return it.stalled?`Waiting for connection · ${it.pct}%`:`${it.pct}% · ${bytes(it.speed)}/s${it.eta?' · '+fmtEta(it.eta)+' left':''}`;
}
function dlRow(it){const el=document.createElement('div');el.className='li';el.dataset.k=it.key;
  el.innerHTML=`<div class="po sm"><img alt=""></div><div class="lt"><b></b><small class="m1"></small><i class="lp"><u></u></i><small class="m2"></small></div><button class="ib sm" data-pp>${''}</button><button class="ib sm" data-rm aria-label="Delete">${ic('trash')}</button>`;return el}
function dlPaint(el,it){
  el.dataset.state=it.state;
  const im=el.querySelector('img'),src=it.poster?`/local/${encodeURIComponent(it.key)}/poster`:pic(it.thumb);if(im.dataset.s!==src){im.dataset.s=src;im.src=src}
  el.querySelector('b').textContent=it.name;
  el.querySelector('.m1').textContent=`${it.label?it.label+' · ':''}Episode ${it.ep} · ${it.mode.toUpperCase()}${it.h?' · '+it.h+'p':''}`;
  el.querySelector('.lp').style.display=it.state==='done'?'none':'';
  el.querySelector('u').style.width=it.pct+'%';el.querySelector('.m2').textContent=stText(it);
  const pp=el.querySelector('[data-pp]'),k=it.state==='done'?'':ST[it.state]?'pause':'play';
  if(pp.dataset.k!==k){pp.dataset.k=k;pp.innerHTML=k?ic(k,'fill'):'';pp.style.display=k?'':'none'}
}
function renderDL(){
  const box=$('#dlist'),have=new Map([...box.children].map(e=>[e.dataset.k,e]));let ref=box.firstElementChild;
  for(const it of dlItems){let el=have.get(it.key);have.delete(it.key);
    if(!el){el=dlRow(it);box.insertBefore(el,ref)}else if(el===ref)ref=ref.nextElementSibling;else box.insertBefore(el,ref);dlPaint(el,it)}
  have.forEach(e=>e.remove());
  $('#dempty').style.display=dlItems.length?'none':'';
  $('#dstat').textContent=dlMeta.free?`${bytes(dlMeta.used)} used · ${bytes(dlMeta.free)} free`:'';
}
async function refreshDL(){
  const d=await api('/api/dl/list').catch(()=>null);if(!d)return;dlItems=d.items;dlMeta=d;
  const act=dlItems.filter(i=>ST[i.state]).length,b=$('#bdg');b.textContent=act;b.classList.toggle('on',act>0);
  if(tab==='dl')renderDL();
  if($('#show').classList.contains('open'))paintEps(false);
  if($('#dsheet').classList.contains('open')&&cs&&dctx&&dctx.ep!=null){const it=dlFor(cs.id,dctx.ep,mode);if(it&&$('#dpanel .lp u')){$('#dpanel .lp u').style.width=it.pct+'%';const n=$('#dpanel .note');if(n)n.textContent=stText(it)}}
}
setInterval(()=>{if(document.hidden)return;if(tab==='dl'||$('#show').classList.contains('open')||dlItems.some(i=>ST[i.state]))refreshDL()},1000);
const rmArm={};
function ctxFromDl(it){
  let g=Object.values(G).find(x=>x.seasons.some(s=>s.id===it.id));
  if(!g)g={key:it.id,name:it.name,thumb:it.thumb,seasons:[{id:it.id,name:it.name,thumb:it.thumb,kind:'season',num:1,part:0,label:it.label||'Season 1'}]};
  return[g,sOf(g,it.id)];
}
function playLocal(it){setMode(it.mode);const[g,s]=ctxFromDl(it);play(g,s,it.ep,{local:it})}

/* ---------- clicks ---------- */
document.addEventListener('click',e=>{
  const t=e.target;let x;
  if(x=t.closest('#nav button'))return setTab(x.dataset.t);
  if(x=t.closest('[data-dq]')){recentQ=recentQ.filter(q=>q!==x.dataset.dq);S.set('rq',recentQ);return showSearchState()}
  if(x=t.closest('[data-sq]')){$('#q').value=x.dataset.sq;addQ(x.dataset.sq);return search()}
  if(t.closest('[data-clrq]')){recentQ=[];S.set('rq',recentQ);return showSearchState()}
  if(t.closest('[data-clra]')){recentA=[];S.set('ra',recentA);return renderHome()}
  if(x=t.closest('[data-lg]')&&t.closest('#sLg')){const c=x.dataset.lg,i=pf.langs.indexOf(c);i>=0?pf.langs.splice(i,1):pf.langs.push(c);S.set('pf',pf);x.classList.toggle('on',i<0);return}
  if(t.closest('#sCc')){post('/api/cache/clear',{}).then(()=>toast('Image cache cleared'));return}
  if(x=t.closest('[data-cont]')){const sid=x.dataset.cont,h=hist[sid],g=gOf(h.gk),s=sOf(g,sid);cg=g;cs=s;
    return done(h)?openShow(g,sid):play(g,s,h.ep)}
  if(x=t.closest('.card[data-g]'))return openShow(gOf(x.dataset.g));
  if(x=t.closest('.li[data-k]')){
    const it=dlItems.find(i=>i.key===x.dataset.k);if(!it)return;
    if(t.closest('[data-pp]')){post('/api/dl/'+(ST[it.state]?'pause':'resume'),{key:it.key}).then(refreshDL);return}
    if(t.closest('[data-rm]')){const b=t.closest('[data-rm]');
      if(rmArm[it.key]){clearTimeout(rmArm[it.key]);delete rmArm[it.key];post('/api/dl/remove',{key:it.key}).then(refreshDL);toast('Deleted')}
      else{b.classList.add('arm');toast('Tap again to delete');rmArm[it.key]=setTimeout(()=>{delete rmArm[it.key];b.classList.remove('arm')},3000)}return}
    return it.done>0?playLocal(it):toast(stText(it));
  }
  if(x=t.closest('#eps .er')){
    const ep=x.dataset.ep;
    if(t.closest('[data-dl]'))return openDl(ep);
    const it=dlFor(cs.id,ep,mode);
    return play(cg,cs,ep,it&&it.state==='done'?{local:it}:{});
  }
});

/* ================================================== player ================================================== */
const resumePos=()=>{const h=hist[cs.id],w=h&&h.w&&h.w[cure];return w&&w[0]>10&&w[0]<w[1]-35?w[0]:0};
const localFor=(sid,ep,m)=>{const it=dlFor(sid,ep,m);return it&&(it.state==='done'||(!navigator.onLine&&it.done>0))?it:null};
let hls=null,cues=[],subList=[],subIdx=-1,master='',refr='',localKey='',playSeq=0,lastSave=0,lastTxt='';
function setLoading(on,txt,err){const l=$('#ld');l.style.display=on||err?'flex':'none';l.classList.toggle('err',!!err);$('#ldt').textContent=txt||'';pl.classList.toggle('loading',!!on&&!err)}
function lockLandscape(){try{if(!document.fullscreenElement)goFs();const o=screen.orientation;o&&o.lock&&o.lock('landscape').catch(()=>{})}catch{}}
function openPlayer(){pl.classList.add('open');pl.classList.remove('hide');openLayer('player',closePlayerNow);lockLandscape();resetZoom(true)}
function destroyHls(){if(hls){hls.destroy();hls=null}}
function closePlayerNow(){
  saveHist();v.pause();destroyHls();v.removeAttribute('src');v.load();playSeq++;rs=null;
  pl.classList.remove('open');closeMenuNow();unwake();
  try{screen.orientation&&screen.orientation.unlock&&screen.orientation.unlock()}catch{}
  if(tab==='home')renderHome();if($('#show').classList.contains('open')){paintEps(true);paintWatch()}
}
function titleHtml(){return `${esc(cg.name)} <small>${cg.seasons.length>1&&cs.label?'· '+esc(cs.label)+' ':''}· Ep ${esc(cure)}</small>`}
async function play(g,s,ep,opt={}){
  const my=++playSeq;cg=g;cs=s;cure=String(ep);G[g.key]=g;
  openPlayer();setLoading(true,'');$('#ttl').innerHTML=titleHtml();
  v.pause();destroyHls();cues=[];subIdx=-1;lastTxt='';$('#sub').textContent='';rs=null;
  const L=opt.local||localFor(s.id,cure,mode);
  try{
    if(!eps.length||epsKey!==s.id+mode){eps=await loadEps(s);epsKey=s.id+mode}
    if(L){
      if(L.mode!==mode)setMode(L.mode);
      localKey=L.key;master=`/local/${encodeURIComponent(L.key)}/master.m3u8`;refr='';
      subList=L.subs.map(t=>({label:t.label,src:`/local/${encodeURIComponent(L.key)}/${t.file}`,local:true,def:t.def}));
    }else{
      localKey='';
      const d=await api(`/api/sources?id=${encodeURIComponent(s.id)}&ep=${encodeURIComponent(cure)}&mode=${mode}`);
      if(my!==playSeq)return;
      if(!d.master)throw new Error(d.error||'No sources found');
      master=d.master;refr=d.refr;
      subList=(d.subs||[]).map((t,i)=>({label:t.label||t.lang||t.language||t.name||'Track '+(i+1),src:t.src||t.file||t.url,def:!!t.default})).filter(t=>t.src);
    }
  }catch(e){if(my===playSeq)setLoading(false,navigator.onLine?(e.message||'Failed to load'):'Offline. Download this episode to watch without internet.',true);return}
  if(my!==playSeq)return;
  startHls(true);
  const want=pf.sl==='Off'?-1:subList.findIndex(t=>new RegExp(pf.sl==='Arabic'?'arab|^ar\\b':'^en|english','i').test(t.label));
  useSub(pf.sl==='Off'?-1:want>=0?want:subList.findIndex(t=>t.def));
  mediaSession();
}
function startHls(fresh){
  const t=fresh?resumePos():v.currentTime,url=localKey?master:px(master,refr);destroyHls();
  const go=()=>{if(t>0)v.currentTime=t;v.playbackRate=pf.sp;v.play().catch(()=>{})};
  if(window.Hls&&Hls.isSupported()){
    hls=new Hls({maxBufferLength:40,fragLoadPolicy:{default:{maxTimeToFirstByteMs:45000,maxLoadTimeMs:120000,timeoutRetry:{maxNumRetry:4,retryDelayMs:0,maxRetryDelayMs:0},errorRetry:{maxNumRetry:6,retryDelayMs:1000,maxRetryDelayMs:8000}}}});
    hls.loadSource(url);hls.attachMedia(v);hls.on(Hls.Events.MANIFEST_PARSED,go);
    hls.on(Hls.Events.ERROR,(e,x)=>{if(!x.fatal)return;
      if(x.type===Hls.ErrorTypes.NETWORK_ERROR)hls.startLoad();else if(x.type===Hls.ErrorTypes.MEDIA_ERROR)hls.recoverMediaError();else setLoading(false,'Playback error',true)});
  }else{v.src=url;v.addEventListener('loadedmetadata',go,{once:true})}
}
/* subtitles */
const ts=x=>x.replace(',','.').split(':').reduce((a,b)=>a*60+parseFloat(b),0);
function parseCues(t){const out=[],rx=/((?:\d+:)?\d+:\d+[.,]\d+)\s*-->\s*((?:\d+:)?\d+:\d+[.,]\d+)[^\n]*\n([\s\S]*?)(?:\n\s*\n|$)/g;let m;t=t.replace(/\r/g,'');
  while(m=rx.exec(t))out.push({s:ts(m[1]),e:ts(m[2]),t:m[3].replace(/<[^>]+>/g,'').replace(/\{\\[^}]*\}/g,'').trim()});return out}
async function useSub(i){subIdx=i;cues=[];lastTxt='';$('#sub').textContent='';if(i<0)return;
  const t=subList[i];try{const r=await fetch(t.local?t.src:px(t.src,refr));if(r.ok&&subIdx===i)cues=parseCues(await r.text())}catch{}}
setInterval(()=>{if(!pl.classList.contains('open'))return;const t=v.currentTime-pf.sd;
  const x=cues.filter(c=>t>=c.s&&t<c.e).map(c=>c.t).join('\n');if(x!==lastTxt){lastTxt=x;$('#sub').textContent=x}},100);
/* history */
function saveHist(){if(!cg||!cs||!v.duration||!isFinite(v.duration)||!cure)return;
  const o=hist[cs.id]||{w:{}};o.gk=cg.key;o.sid=cs.id;o.ep=cure;o.pos=v.currentTime;o.dur=v.duration;o.t=Date.now();o.w=o.w||{};o.w[cure]=[v.currentTime,v.duration];
  hist[cs.id]=o;S.set('hist',hist);addRecentSilent()}
function addRecentSilent(){if(!G[cg.key]){G[cg.key]=cg;S.set('G',G)}}
function stepEp(d){
  const i=eps.indexOf(cure)+d;
  if(eps[i]){saveHist();return play(cg,cs,eps[i])}
  if(d>0){const j=cg.seasons.indexOf(cs),ns=cg.seasons[j+1];
    if(ns){saveHist();toast(ns.label);loadEps(ns).then(l=>{eps=l;epsKey=ns.id+mode;if(l[0])play(cg,ns,l[0])});return}}
  toast(d>0?'No more episodes':'This is the first episode');
}
v.onended=()=>stepEp(1);

/* ---- instant seeking: pause right away, jump, resume the moment the new spot is ready ---- */
let rs=null,rsT=0;                         // rs: null = not seeking, else "was playing"
const buffered=t=>{for(let i=0;i<v.buffered.length;i++)if(t>=v.buffered.start(i)&&t<=v.buffered.end(i)-0.3)return true;return false};
function paintTime(t){const d=v.duration||0;$('#cur').textContent=fmtT(t);if(d){const p=t/d*1000;$('#seek').value=p;$('#seek').style.setProperty('--v',p/10+'%')}}
function seekTo(t){
  const d=v.duration||1e9;t=clamp(t,0,Math.max(0,d-0.3));
  if(rs===null)rs=!v.paused;
  v.pause();setLoading(true,'');paintTime(t);
  if(hls&&!buffered(t))hls.startLoad(t);
  v.currentTime=t;
  clearTimeout(rsT);rsT=setTimeout(finishSeek,15000);
}
function finishSeek(){if(rs===null)return;clearTimeout(rsT);const r=rs;rs=null;setLoading(false);if(r)v.play().catch(()=>{});else syncPP()}
v.addEventListener('seeked',()=>{if(rs!==null&&v.readyState>=3)finishSeek()});
v.addEventListener('canplay',()=>{if(rs!==null)finishSeek()});
const syncPP=()=>{$('#pp').innerHTML=ic(v.paused?'play':'pause','fill')};
const tg=()=>{if(rs!==null)return;v.paused?v.play().catch(()=>{}):v.pause()};$('#pp').onclick=()=>{tg();kick()};
$('#rw').onclick=()=>bump(-10);$('#ff').onclick=()=>bump(10);
let wl=null;
async function wake(){try{if('wakeLock' in navigator&&!wl){wl=await navigator.wakeLock.request('screen');wl.addEventListener('release',()=>wl=null)}}catch{}}
function unwake(){try{wl&&wl.release()}catch{}wl=null}
document.addEventListener('visibilitychange',()=>{if(!document.hidden&&!v.paused&&pl.classList.contains('open'))wake()});
v.onplay=()=>{syncPP();kick();wake()};
v.onpause=()=>{if(rs!==null)return;syncPP();saveHist();unwake()};
v.onwaiting=()=>{if(rs===null)setLoading(true,'')};
v.onplaying=()=>{setLoading(false)};
let scrub=false,scT=0;
v.ontimeupdate=()=>{if(!scrub&&rs===null&&v.duration)paintTime(v.currentTime);else if(rs===null)$('#cur').textContent=fmtT(v.currentTime);
  $('#dur').textContent=fmtT(v.duration||0);if(Date.now()-lastSave>3000){lastSave=Date.now();saveHist()}};
v.ondurationchange=()=>{$('#dur').textContent=fmtT(v.duration||0);zmetrics()};
v.onloadedmetadata=()=>zmetrics();
const seek=$('#seek');
seek.addEventListener('pointerdown',()=>{scrub=true;if(rs===null)rs=!v.paused;v.pause();setLoading(true,'');kick()});
seek.addEventListener('input',()=>{const t=seek.value/1000*(v.duration||0);seek.style.setProperty('--v',seek.value/10+'%');$('#cur').textContent=fmtT(t);
  const n=performance.now();if(n-scT>220){scT=n;try{v.currentTime=t}catch{}}});
seek.addEventListener('change',()=>{scrub=false;seekTo(seek.value/1000*(v.duration||0))});
seek.addEventListener('pointercancel',()=>{scrub=false;finishSeek()});
addEventListener('resize',()=>{zmetrics();resetZoom(true)});

/* ---- elastic pinch zoom: 1x (fit) up to fill-the-screen; rubber-bands past both ends and springs back ---- */
const Z={s:1,x:0,y:0,max:1,W:1,H:1,dw:1,dh:1},zoomEl=$('#zoom');
function zmetrics(){const W=pl.clientWidth||innerWidth,H=pl.clientHeight||innerHeight,vw=v.videoWidth||16,vh=v.videoHeight||9,k=Math.min(W/vw,H/vh);
  Z.W=W;Z.H=H;Z.dw=vw*k;Z.dh=vh*k;Z.max=Math.max(1,W/Z.dw,H/Z.dh);if(Z.max<1.03)Z.max=1}
const lim=s=>({x:Math.max(0,(Z.dw*s-Z.W)/2),y:Math.max(0,(Z.dh*s-Z.H)/2)});
const rub=(o,r)=>r*(1-1/(o*.6/r+1));
function soft(x,l,r){return x>l?l+rub(x-l,r):x<-l?-l-rub(-l-x,r):x}
function applyZ(){zoomEl.style.transform=`translate(${Z.x}px,${Z.y}px) scale(${Z.s})`;fitIcon()}
function fitIcon(){const on=Z.s>1.01;$('#fit').innerHTML=ic(on?'compress':'expand');$('#fit').dataset.on=on?1:0}
let snapT=0;
function snapZ(){            // release: clamp to [1, fill] and spring back
  zmetrics();let s=clamp(Z.s,1,Z.max);if(Math.abs(s-1)<.03)s=1;if(Math.abs(s-Z.max)<.03*Z.max)s=Z.max;
  const l=lim(s);Z.s=s;Z.x=clamp(Z.x,-l.x,l.x);Z.y=clamp(Z.y,-l.y,l.y);if(s===1){Z.x=0;Z.y=0}
  zoomEl.classList.add('snap');applyZ();clearTimeout(snapT);snapT=setTimeout(()=>zoomEl.classList.remove('snap'),480);
}
function resetZoom(now){zmetrics();Z.s=1;Z.x=0;Z.y=0;if(now){zoomEl.classList.remove('snap')}applyZ()}
function toggleFit(){zmetrics();if(Z.max<=1){badge('Already fills the screen');return}Z.s=Z.s>1.01?1:Z.max;Z.x=0;Z.y=0;zoomEl.classList.add('snap');applyZ();clearTimeout(snapT);snapT=setTimeout(()=>zoomEl.classList.remove('snap'),480);badge(Z.s>1?'Fill screen':'Fit')}
$('#fit').onclick=()=>{toggleFit();kick()};
let badgeT;function badge(t){const b=$('#badge');b.textContent=t;b.classList.add('show');clearTimeout(badgeT);badgeT=setTimeout(()=>b.classList.remove('show'),1100)}
const stage=$('#stage');let pin=null,pan=null,noTapUntil=0;
const dist=t=>Math.hypot(t[0].clientX-t[1].clientX,t[0].clientY-t[1].clientY),mid=t=>({x:(t[0].clientX+t[1].clientX)/2-Z.W/2,y:(t[0].clientY+t[1].clientY)/2-Z.H/2});
stage.addEventListener('touchstart',e=>{
  if(e.target.closest('#menu,#seek,button'))return;
  if(e.touches.length===2){zmetrics();clearTimeout(snapT);zoomEl.classList.remove('snap');pan=null;
    pin={d:dist(e.touches),s:Z.s,x:Z.x,y:Z.y,m:mid(e.touches)};pl.classList.add('zooming');noTapUntil=performance.now()+500}
  else if(e.touches.length===1&&Z.s>1.01&&!pin){zmetrics();clearTimeout(snapT);zoomEl.classList.remove('snap');pan={x:e.touches[0].clientX,y:e.touches[0].clientY,ox:Z.x,oy:Z.y,moved:false}}
},{passive:true});
stage.addEventListener('touchmove',e=>{
  if(pin&&e.touches.length>=2){
    e.preventDefault();const raw=pin.s*dist(e.touches)/pin.d;
    const s=raw<1?1-rub(1-raw,.22):raw>Z.max?Z.max+rub(raw-Z.max,.18*Z.max):raw;
    const m=mid(e.touches),k=s/pin.s;
    let x=m.x-(pin.m.x-pin.x)*k,y=m.y-(pin.m.y-pin.y)*k;const l=lim(s);
    Z.s=s;Z.x=soft(x,l.x,70);Z.y=soft(y,l.y,70);applyZ();noTapUntil=performance.now()+500;
  }else if(pan&&e.touches.length===1){
    const dx=e.touches[0].clientX-pan.x,dy=e.touches[0].clientY-pan.y;
    if(!pan.moved&&Math.hypot(dx,dy)<9)return;pan.moved=true;noTapUntil=performance.now()+350;e.preventDefault();
    const l=lim(Z.s);Z.x=soft(pan.ox+dx,l.x,70);Z.y=soft(pan.oy+dy,l.y,70);applyZ();
  }
},{passive:false});
function endTouch(e){
  if(pin&&e.touches.length<2){pin=null;pl.classList.remove('zooming');snapZ();noTapUntil=performance.now()+450;
    if(e.touches.length===1&&Z.s>1.01)pan={x:e.touches[0].clientX,y:e.touches[0].clientY,ox:Z.x,oy:Z.y,moved:true};kick();return}
  if(pan&&e.touches.length===0){const mv=pan.moved;pan=null;if(mv){snapZ();noTapUntil=performance.now()+300}}
}
stage.addEventListener('touchend',endTouch,{passive:true});stage.addEventListener('touchcancel',endTouch,{passive:true});

/* ---- controls: auto-hide, double-tap skip ---- */
let ht;function kick(){pl.classList.remove('hide');clearTimeout(ht);ht=setTimeout(()=>{if(!v.paused&&!$('#menu').classList.contains('open')&&rs===null)pl.classList.add('hide')},3200)}
const toggleUI=()=>pl.classList.contains('hide')?kick():pl.classList.add('hide');
pl.addEventListener('mousemove',()=>{if(!pl.classList.contains('hide'))kick()});
let pend=0,skT=0,lastTap={t:0,z:9},stT=0;
function bump(d){
  pend+=d;seekTo(v.currentTime+d);kick();
  const k=$('#skip');k.className='show '+(pend<0?'l':'r');
  k.innerHTML=ic(pend<0?'chevs-l':'chevs-r')+`<span>${pend>0?'+':''}${pend}s</span>`;k.classList.remove('pop');void k.offsetWidth;k.classList.add('pop');
  clearTimeout(skT);skT=setTimeout(()=>{pend=0;k.className=''},850);
}
stage.addEventListener('click',e=>{
  if(e.target.closest('button,input,#menu'))return;
  if(performance.now()<noTapUntil)return;
  if($('#menu').classList.contains('open')){history.back();return}
  const f=e.clientX/Z.W,z=f<.35?-1:f>.65?1:0,n=performance.now();
  if(pend&&z&&Math.sign(pend)===z){bump(z*10);lastTap={t:n,z};return}
  if(n-lastTap.t<300&&lastTap.z===z){clearTimeout(stT);lastTap={t:0,z:9};z?bump(z*10):(tg(),kick());return}
  lastTap={t:n,z};clearTimeout(stT);stT=setTimeout(toggleUI,300);
});
$('#bot').addEventListener('pointerdown',()=>kick());
document.addEventListener('keydown',e=>{if(!pl.classList.contains('open')||e.target.id==='q')return;const k=e.key;
  if(k===' '||k==='k'){e.preventDefault();tg()}
  else if(k==='ArrowRight'||k==='l')bump(10);else if(k==='ArrowLeft'||k==='j')bump(-10);
  else if(k==='f')toggleFit();else if(k==='m'){v.muted=!v.muted;toast(v.muted?'Muted':'Unmuted')}
  else if(k==='n')stepEp(1);else if(k==='Escape')history.back();
  kick()});
addEventListener('pagehide',()=>{saveHist();push()});
function mediaSession(){
  if(!('mediaSession' in navigator))return;
  try{navigator.mediaSession.metadata=new MediaMetadata({title:'Episode '+cure,artist:cg.name,artwork:cg.thumb?[{src:location.origin+pic(cg.thumb),sizes:'300x450',type:'image/jpeg'}]:[]});
    const a=(n,f)=>{try{navigator.mediaSession.setActionHandler(n,f)}catch{}};
    a('play',()=>v.play());a('pause',()=>v.pause());a('nexttrack',()=>stepEp(1));a('previoustrack',()=>stepEp(-1));a('seekforward',()=>bump(10));a('seekbackward',()=>bump(-10))}catch{}
}

/* ---- options menu (top right): every option gets its own row, each opens its own page ---- */
let mpage='root',moreSubs=null;
function openMenu(){$('#menu').classList.add('open');$('#mscrim').classList.add('open');mpage='root';renderMenu();openLayer('menu',closeMenuNow);pl.classList.remove('hide');clearTimeout(ht)}
function closeMenuNow(){$('#menu').classList.remove('open');$('#mscrim').classList.remove('open');kick()}
$('#opt').onclick=()=>$('#menu').classList.contains('open')?history.back():openMenu();
$('#mscrim').onclick=()=>history.back();
const curLabel=()=>subIdx>=0&&subList[subIdx]?subList[subIdx].label:'Off';
const qLabel=()=>!hls||hls.currentLevel<0?'Auto':(hls.levels[hls.currentLevel]||{}).height+'p';
const sdLabel=()=>(pf.sd>0?'+':'')+pf.sd.toFixed(1)+'s';
function row(go,icon,label,val,on){return `<button class="r ${on?'on':''}" data-go="${go}">${ic(icon)}<span>${label}</span>${val!=null?`<em>${esc(val)}</em>`:''}${go?ic('chev-r'):''}</button>`}
function renderMenu(){
  const h=$('#mh'),b=$('#mb');
  const T={root:'Settings',cc:'Subtitles',sp:'Speed',q:'Quality',ss:'Subtitle size',sd:'Subtitle timing'};
  h.innerHTML=(mpage!=='root'?`<button class="ib" data-mback>${ic('back')}</button>`:'')+`<span>${T[mpage]}</span>`;
  if(mpage==='root'){
    b.innerHTML=row('cc','cc','Subtitles',curLabel())+row('sp','gauge','Speed',pf.sp+'x')+row('q','layers','Quality',qLabel())+row('ss','text','Subtitle size',pf.ss+'px')+row('sd','timer','Subtitle timing',sdLabel())
      +`<div class="sec">Episode</div><button class="r" data-act="prev">${ic('next')}<span>Previous episode</span></button><button class="r" data-act="next">${ic('next')}<span>Next episode</span></button>`;
    const bs=b.querySelectorAll('[data-act="prev"] .ic');if(bs[0])bs[0].style.transform='scaleX(-1)';
  }else if(mpage==='cc'){
    b.innerHTML=`<button class="r ${subIdx<0?'on':''}" data-cc="-1"><span>Off</span></button>`+subList.map((t,i)=>`<button class="r ${subIdx===i?'on':''}" data-cc="${i}"><span>${esc(t.label)}</span></button>`).join('')+`<div id="moresubs"></div>`;
    if(!localKey)loadMoreSubs();
  }else if(mpage==='sp'){
    b.innerHTML=[.5,.75,1,1.25,1.5,1.75,2,2.5,3].map(x=>`<button class="r ${pf.sp==x?'on':''}" data-sp="${x}"><span>${x}x</span></button>`).join('');
  }else if(mpage==='q'){
    const L=hls?hls.levels:[];
    b.innerHTML=`<button class="r ${!hls||hls.currentLevel<0?'on':''}" data-q="-1"><span>Auto</span></button>`+L.map((l,i)=>`<button class="r ${hls.currentLevel===i?'on':''}" data-q="${i}"><span>${l.height?l.height+'p':Math.round(l.bitrate/1000)+'k'}</span></button>`).join('')||'<p class="note" style="padding:14px">Only one quality available.</p>';
  }else if(mpage==='ss'){
    b.innerHTML=`<div class="ctl"><div class="val"><span>Size</span><b id="ssv">${pf.ss}px</b></div><input type="range" id="ssz" min="14" max="64" value="${pf.ss}"></div>`;
  }else if(mpage==='sd'){
    b.innerHTML=`<div class="step"><button data-sdm="-0.5">−</button><b id="sdv">${sdLabel()}</b><button data-sdm="0.5">+</button></div><p class="note" style="text-align:center">If the subtitles show too early or too late, nudge them here.</p><button class="r" data-sdm="reset" style="justify-content:center"><span style="flex:none">Reset</span></button>`;
  }
}
async function loadMoreSubs(){
  const box=$('#moresubs');if(!box||!cs||cs.type)return;
  box.innerHTML='<div class="sec">More languages</div><p class="note" style="padding:6px 12px"><span class="spin sm"></span>Searching…</p>';
  const key=cs.id+cure;if(!moreSubs||moreSubs.key!==key){const d=await api('/api/subs/find?'+subParams(cure)).catch(()=>({subs:[]}));moreSubs={key,subs:d.subs||[],reason:d.reason}}
  const b=$('#moresubs');if(!b||mpage!=='cc')return;
  const have=new Set(subList.map(t=>t.label));
  const L=moreSubs.subs.filter(s=>!have.has(s.label));
  b.innerHTML=L.length?'<div class="sec">More languages</div>'+L.map(s=>`<button class="r" data-more="${esc(s.url)}" data-ml="${esc(s.label)}"><span>${esc(s.label)}</span><em>download &amp; show</em></button>`).join(''):'';
}
$('#mh').addEventListener('click',e=>{if(e.target.closest('[data-mback]')){mpage='root';renderMenu()}});
$('#mb').addEventListener('click',e=>{
  const b=e.target.closest('button');if(!b)return;const d=b.dataset;
  if(d.go){mpage=d.go;renderMenu();return}
  if(d.act){history.back();setTimeout(()=>stepEp(d.act==='next'?1:-1),200);return}
  if(d.cc!==undefined){useSub(+d.cc);pf.sl=+d.cc<0?'Off':(/arab/i.test(curLabelOf(+d.cc))?'Arabic':'English');S.set('pf',pf);mpage='root';renderMenu();return}
  if(d.more){subList.push({label:d.ml,src:'/api/subs/get?url='+encodeURIComponent(d.more),local:true});useSub(subList.length-1);toast(d.ml);mpage='root';renderMenu();return}
  if(d.sp){pf.sp=+d.sp;v.playbackRate=pf.sp;S.set('pf',pf);toast('Speed '+pf.sp+'x');mpage='root';renderMenu();return}
  if(d.q!==undefined&&hls){hls.currentLevel=+d.q;toast(+d.q<0?'Quality: Auto':'Quality: '+b.textContent);mpage='root';renderMenu();return}
  if(d.sdm!==undefined){pf.sd=d.sdm==='reset'?0:Math.round((pf.sd+ +d.sdm)*10)/10;S.set('pf',pf);const x=$('#sdv');if(x)x.textContent=sdLabel()}
});
const curLabelOf=i=>subList[i]?subList[i].label:'';
$('#mb').addEventListener('input',e=>{if(e.target.id==='ssz'){pf.ss=+e.target.value;document.documentElement.style.setProperty('--ss',pf.ss+'px');$('#ssv').textContent=pf.ss+'px';S.set('pf',pf)}});

/* ---------- boot ---------- */
(async()=>{
  importOld();
  await Promise.race([pull(),sleep(1500)]);
  loadState();
  setMode(mode);$('#pp').innerHTML=ic('pause','fill');fitIcon();
  setTab(S.loc('tab','home'));refreshDL();
})();
