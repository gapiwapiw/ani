'use strict';
const http=require('http'),fs=require('fs'),path=require('path'),crypto=require('crypto');
const{execFile,execFileSync}=require('child_process'),{Readable}=require('stream');
const DIR=__dirname,PORT=+process.env.PORT||1222,BASE='https://hianime.at/';
/* All user data lives in ./storage so updating the code never touches it. */
const STORE=process.env.ANI_STORAGE||path.join(DIR,'storage'),PUB=path.join(DIR,'public');
const DLDIR=process.env.ANI_GUI_DL||path.join(STORE,'downloads'),CACHE=path.join(STORE,'cache'),DATA=path.join(STORE,'data'),HLS=path.join(PUB,'hls.min.js');
for(const d of[STORE,CACHE,DATA,DLDIR])fs.mkdirSync(d,{recursive:true});
// one-time safety net: move data from the old layout (./downloads, ./cache) into ./storage
for(const[o,n]of[['downloads',DLDIR],['cache',CACHE]]){
  const old=path.join(DIR,o);
  try{if(fs.statSync(old).isDirectory()&&old!==n){for(const f of fs.readdirSync(old)){const t=path.join(n,f);if(!fs.existsSync(t))fs.renameSync(path.join(old,f),t)}fs.rmdirSync(old)}}catch{}
}
try{const o=path.join(DIR,'hls.min.js');if(fs.existsSync(o)&&!fs.existsSync(HLS)){fs.mkdirSync(PUB,{recursive:true});fs.renameSync(o,HLS)}}catch{}
process.on('uncaughtException',e=>console.error('uncaught:',e.message));
process.on('unhandledRejection',e=>console.error('unhandled:',e&&e.message||e));

/* ---------- ani-cli bridge ---------- */
function findAniCli(){
  const c=[process.env.ANI_CLI,path.join(process.env.HOME||'','ani-cli','ani-cli')];
  try{c.push(execFileSync('sh',['-c','command -v ani-cli']).toString().trim())}catch{}
  return c.find(p=>p&&fs.existsSync(p)&&fs.statSync(p).isFile());
}
const AC=findAniCli();
if(!AC){console.error('ani-cli not found. Run: git clone https://github.com/pystardust/ani-cli ~/ani-cli');process.exit(1)}
const src=fs.readFileSync(AC,'utf8'),cut=src.indexOf('\nwhile [ $# -gt 0 ]; do');
if(cut<0||!src.includes('hianime_m3u8')){console.error('Unsupported ani-cli at '+AC+'\nUpdate it: git -C ~/ani-cli pull');process.exit(1)}
fs.writeFileSync(path.join(DIR,'lib.sh'),src.slice(0,cut)+'\n');
const UA=(src.match(/^agent="([^"]*)"/m)||[])[1]||'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';
let CURL='curl';
for(const c of['curl_firefox135','curl_chrome136','curl_chrome116','curl_ff117']){try{execFileSync('sh',['-c','command -v '+c],{stdio:'ignore'});CURL=c;break}catch{}}
console.log('ani-cli: '+AC+' | curl: '+CURL);

const clean=s=>String(s||'').replace(/\x1b\[[0-9;]*[A-Za-z]/g,'').replace(/\r/g,'').trim();
const run=(args,env={})=>new Promise((ok,no)=>execFile('sh',[path.join(DIR,'bridge.sh'),...args],
  {env:{...process.env,...env},timeout:45000,maxBuffer:50e6},(e,out,err)=>e?no(new Error(clean(err)||e.message)):ok(out)));
const curlText=(url,ref)=>new Promise((ok,no)=>execFile(CURL,['-sL','-A',UA,'-e',ref||BASE,'--max-time','20',url],{maxBuffer:50e6},(e,o)=>e?no(e):ok(o)));
const px=(u,r)=>'/proxy?url='+encodeURIComponent(u)+'&ref='+encodeURIComponent(r);
function rewrite(t,url,ref){const b=new URL(url);return t.split('\n').map(l=>{l=l.trim();if(!l)return l;
  if(l[0]!=='#')return px(new URL(l,b).href,ref);
  return l.replace(/URI="([^"]+)"/g,(m,x)=>'URI="'+px(new URL(x,b).href,ref)+'"')}).join('\n')}
function thumbs(html){
  const out={},parts=html.split('id="main-sidebar"')[0].split('<div class="film-detail">');
  for(let i=1;i<parts.length;i++){
    const m=parts[i].match(/<h3 class="film-name">\s*<a href="[^"]*\/([^"\/]*)"/);
    const im=[...parts[i-1].matchAll(/(?:data-src|src)="(https?:[^"]+)"/g)];
    if(m&&im.length)out[m[1]]=im[im.length-1][1].replace(/&amp;/g,'&');
  }
  return out;
}
const epMaps={};
async function getSources(id,ep,mode){
  const o=await run(['sources',id,ep,mode],epMaps[id]?{EPMAPS:epMaps[id]}:{});
  const g=k=>(o.split('\n').find(l=>l.startsWith(k+'\t'))||'').slice(k.length+1).trim();
  let subs=[];try{subs=JSON.parse(g('JSON')).subtitles||[]}catch{}
  if(!subs.length&&g('SUB'))subs=[{label:'Default',src:g('SUB'),default:true}];
  return{master:g('MASTER'),refr:g('REFR'),subs};
}
const subs=require('./subs.js')({dir:path.join(DATA,'meta'),UA});
const dl=require('./dl.js')({dir:DLDIR,UA,BASE,curlText,resolve:getSources,fetchVtt:subs.fetchVtt});
const{group}=require('./group.js');
const epCount=async id=>{
  if(!epMaps[id])epMaps[id]=(await run(['episodes',id])).trim();
  return epMaps[id].split('\n').filter(Boolean).length;
};
const STATE=path.join(DATA,'state.json');
const readState=()=>{try{return JSON.parse(fs.readFileSync(STATE,'utf8'))}catch{return{}}};

/* ---------- offline assets: hls.js + image cache ---------- */
(async()=>{
  if(fs.existsSync(HLS)&&fs.statSync(HLS).size>1e5)return;
  try{const r=await fetch('https://cdn.jsdelivr.net/npm/hls.js@1.5.17/dist/hls.min.js');
    if(r.ok){fs.writeFileSync(HLS,Buffer.from(await r.arrayBuffer()));console.log('hls.js saved locally (works offline now)')}}
  catch{console.warn('! hls.min.js missing and could not be downloaded; connect once and restart')}
})();
try{for(const f of fs.readdirSync(CACHE)){const p=path.join(CACHE,f);if(Date.now()-fs.statSync(p).mtimeMs>30*864e5)fs.rmSync(p,{force:true})}}catch{}
const EXT={'image/jpeg':'jpg','image/png':'png','image/webp':'webp','image/gif':'gif','image/avif':'avif'};
const CT=Object.fromEntries(Object.entries(EXT).map(([k,v])=>[v,k]));
const MIME={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.svg':'image/svg+xml','.png':'image/png','.webmanifest':'application/manifest+json','.json':'application/json','.ico':'image/x-icon'};
const ctOf=f=>/\.m3u8$/.test(f)?'application/vnd.apple.mpegurl':/\.vtt$/.test(f)?'text/vtt; charset=utf-8':f==='poster'?'image/jpeg':'application/octet-stream';

function sendFile(req,res,p,ct,extra={}){
  let st;try{st=fs.statSync(p)}catch{res.writeHead(404);return res.end()}
  const h={'Content-Type':ct,'Accept-Ranges':'bytes',...extra};
  const m=/bytes=(\d*)-(\d*)/.exec(req.headers.range||'');
  let a=0,b=st.size-1,code=200;
  if(m&&(m[1]||m[2])){
    a=m[1]?+m[1]:Math.max(0,st.size-+m[2]);b=m[1]&&m[2]?Math.min(+m[2],st.size-1):st.size-1;
    if(a>b||a>=st.size){res.writeHead(416,{'Content-Range':'bytes */'+st.size});return res.end()}
    code=206;h['Content-Range']=`bytes ${a}-${b}/${st.size}`;
  }
  h['Content-Length']=b-a+1;res.writeHead(code,h);
  if(st.size===0)return res.end();
  const s=fs.createReadStream(p,{start:a,end:b});s.on('error',()=>res.end());res.on('close',()=>s.destroy());s.pipe(res);
}
async function image(req,res,url){
  const h=crypto.createHash('sha1').update(url).digest('hex'),hdr={'Cache-Control':'public,max-age=604800'};
  for(const e of Object.values(EXT)){const p=path.join(CACHE,h+'.'+e);if(fs.existsSync(p))return sendFile(req,res,p,CT[e],hdr)}
  const r=await fetch(url,{headers:{'User-Agent':UA,Referer:BASE},signal:AbortSignal.timeout(15000)});
  const ct=(r.headers.get('content-type')||'').split(';')[0],e=EXT[ct];
  if(!r.ok||!e){res.writeHead(404);return res.end()}
  const p=path.join(CACHE,h+'.'+e);fs.writeFileSync(p,Buffer.from(await r.arrayBuffer()));
  sendFile(req,res,p,ct,hdr);
}
const body=req=>new Promise(ok=>{let b='';req.on('data',c=>{b+=c;if(b.length>5e6)req.destroy()});req.on('end',()=>{try{ok(JSON.parse(b||'{}'))}catch{ok({})}});req.on('error',()=>ok({}))});
const okId=s=>/^[\w-]+$/.test(s||''),okEp=s=>/^[\w.-]+$/.test(s||''),okKey=s=>/^[\w.~-]+$/.test(s||'');
function storage(){
  let free=0;try{const s=fs.statfsSync(DLDIR);free=s.bavail*s.bsize}catch{}
  return{free,used:dl.list().reduce((a,i)=>a+i.bytes,0)};
}

/* ---------- http ---------- */
const server=http.createServer(async(req,res)=>{
  const u=new URL(req.url,'http://x'),q=u.searchParams;
  const json=(o,c=200)=>{res.writeHead(c,{'Content-Type':'application/json','Cache-Control':'no-store'});res.end(JSON.stringify(o))};
  const id=q.get('id')||'',ep=q.get('ep')||'',mode=q.get('mode')==='dub'?'dub':'sub';
  try{
    const P=u.pathname;
    if(P==='/'||P==='/index.html'){return sendFile(req,res,path.join(PUB,'index.html'),MIME['.html'],{'Cache-Control':'no-store'})}
    if(P==='/hls.min.js'){if(!fs.existsSync(HLS)){res.writeHead(404);return res.end()}return sendFile(req,res,HLS,'text/javascript',{'Cache-Control':'public,max-age=31536000'})}
    if(/^\/[\w.-]+\.(css|js|svg|png|webmanifest|ico)$/.test(P)){
      const f=path.join(PUB,P.slice(1));
      if(fs.existsSync(f))return sendFile(req,res,f,MIME[path.extname(f)]||'application/octet-stream',{'Cache-Control':'no-cache'});
    }
    if(P==='/api/health')return json({ok:true,ani:AC,downloads:dl.list().length});
    if(P==='/img'){const t=q.get('url')||'';if(!/^https?:\/\//.test(t)){res.writeHead(400);return res.end()}return await image(req,res,t)}

    if(P==='/api/search'){
      const enc=encodeURIComponent((q.get('q')||'').trim()).replace(/%20/g,'+');
      const[list,page]=await Promise.all([run(['search',enc]),run(['page',enc]).catch(()=>'')]);
      const t=thumbs(page);
      const results=list.split('\n').filter(Boolean).map(l=>{const[i,...n]=l.split('\t');return{id:i,name:n.join('\t'),thumb:t[i]||''}});
      return json({results,groups:group(results)});
    }
    if(P==='/api/episodes'){
      if(!okId(id))return json({error:'bad id',eps:[]},400);
      const o=await run(['episodes',id]);epMaps[id]=o.trim();
      const eps=o.split('\n').filter(Boolean).map(l=>l.split('\t')[1]).filter(Boolean);
      return json({eps:eps.sort((a,b)=>parseFloat(a)-parseFloat(b))});
    }
    if(P==='/api/info'){            // IMDb-style details (description, rating, episode titles); optional, may be empty
      const t=(q.get('title')||'').trim();if(!t)return json({});
      try{return json((await subs.info(t))||{})}catch{return json({})}
    }
    if(P==='/api/subs/find'){       // which extra subtitle languages exist for this episode?
      const off=(q.get('offsetIds')||'').split(',').filter(okId);
      let offset=0;try{for(const i of off)offset+=await epCount(i)}catch{}
      try{return json(await subs.find({title:q.get('title')||'',season:q.get('season'),episode:q.get('ep'),count:q.get('count'),offset}))}
      catch(e){return json({subs:[],reason:'Subtitle service unreachable'})}
    }
    if(P==='/api/subs/get'){
      const u=q.get('url')||'';let h='';try{h=new URL(u).hostname}catch{}
      if(!/^https:\/\/[\w.-]+\.strem\.io\//.test(u)&&!process.env.ANI_OSUB){res.writeHead(400);return res.end()}
      const t=await subs.fetchVtt(u);res.writeHead(200,{'Content-Type':'text/vtt; charset=utf-8'});return res.end(t);
    }
    if(P==='/api/cache/clear'&&req.method==='POST'){try{for(const f of fs.readdirSync(CACHE))fs.rmSync(path.join(CACHE,f),{force:true})}catch{}return json({ok:true})}
    if(P==='/api/state'){
      if(req.method==='POST'){const b=await body(req);const s={...readState(),...b};fs.writeFileSync(STATE+'.tmp',JSON.stringify(s));fs.renameSync(STATE+'.tmp',STATE);return json({ok:true})}
      return json(readState());
    }
    if(P==='/api/sources'){
      if(!okId(id)||!okEp(ep))return json({error:'bad params'},400);
      return json(await getSources(id,ep,mode));
    }

    /* downloads */
    if(P==='/api/dl/list')return json({items:dl.list(),...storage()});
    if(P==='/api/dl/start'&&req.method==='POST'){
      const b=await body(req);
      if(!okId(b.id))return json({error:'bad id'},400);
      const eps=(Array.isArray(b.eps)?b.eps:[b.ep]).map(String).filter(okEp);
      if(!eps.length)return json({error:'no episodes'},400);
      const q2=['best','1080','720','540','360'].includes(String(b.q))?String(b.q):'best';
      const xs=Array.isArray(b.subs)?b.subs:[];
      const keys=eps.map(e=>dl.start({id:b.id,name:String(b.name||b.id).slice(0,200),label:String(b.label||'').slice(0,80),thumb:/^https?:/.test(b.thumb||'')?b.thumb:'',ep:e,mode:b.mode,q:q2,subs:xs}));
      if(Array.isArray(b.subLangs)&&b.subLangs.length&&b.title){          // batch: look up subtitles per episode in the background
        (async()=>{let offset=0;try{for(const i of(Array.isArray(b.offsetIds)?b.offsetIds:[]).filter(okId))offset+=await epCount(i)}catch{}
          for(const e of eps){try{const r=await subs.find({title:String(b.title),season:b.season,episode:e,count:b.count,offset});
            const xs=(r.subs||[]).filter(x=>b.subLangs.includes(x.lang)).map(x=>({lang:x.lang,label:x.label,url:x.url}));
            if(xs.length)dl.start({id:b.id,name:String(b.name||b.id).slice(0,200),label:String(b.label||'').slice(0,80),thumb:/^https?:/.test(b.thumb||'')?b.thumb:'',ep:e,mode:b.mode,q:q2,subs:xs})}catch{}}})();
      }
      return json({ok:true,keys});
    }
    if(/^\/api\/dl\/(pause|resume|remove)$/.test(P)&&req.method==='POST'){
      const b=await body(req);if(!okKey(b.key))return json({error:'bad key'},400);
      dl[P.split('/').pop()](b.key);return json({ok:true});
    }
    if(P.startsWith('/local/')){
      const[,,key,f]=P.split('/').map(decodeURIComponent);
      if(!okKey(key)||!f){res.writeHead(400);return res.end()}
      const p=await dl.file(key,f);
      if(!p){res.writeHead(404);return res.end()}
      return sendFile(req,res,p,ctOf(f),{'Cache-Control':'no-store'});
    }

    if(P==='/proxy'){
      const url=q.get('url'),ref=q.get('ref')||BASE;
      if(!/^https?:\/\//.test(url||''))return json({error:'bad url'},400);
      if(/\.m3u8/i.test(url.split('?')[0])){
        res.writeHead(200,{'Content-Type':'application/vnd.apple.mpegurl'});return res.end(rewrite(await curlText(url,ref),url,ref));
      }
      const r=await fetch(url,{headers:{'User-Agent':UA,Referer:ref,...(req.headers.range?{Range:req.headers.range}:{})}});
      const ct=r.headers.get('content-type')||'';
      if(/mpegurl/i.test(ct)){res.writeHead(200,{'Content-Type':'application/vnd.apple.mpegurl'});return res.end(rewrite(await r.text(),url,ref))}
      const h={'Content-Type':ct||'application/octet-stream'};
      for(const k of['content-length','content-range','accept-ranges'])if(r.headers.get(k))h[k]=r.headers.get(k);
      res.writeHead(r.status,h);
      const s=Readable.fromWeb(r.body);s.on('error',()=>res.end());res.on('close',()=>s.destroy());
      return s.pipe(res);
    }
    res.writeHead(404);res.end();
  }catch(e){
    console.error(req.url.slice(0,80),e.message);
    if(!res.headersSent)json({error:e.message,results:[],eps:[]},500);else res.end();
  }
});
server.on('error',e=>{console.error(e.code==='EADDRINUSE'?'Port '+PORT+' is busy. Already running? (ani stop)':e.message);process.exit(1)});
server.listen(PORT,'127.0.0.1',()=>console.log('ani -> http://localhost:'+PORT));
for(const s of['SIGINT','SIGTERM','SIGHUP'])process.on(s,()=>{dl.flush();process.exit(0)});
