'use strict';
// Extra subtitle languages: Cinemeta (find the IMDb id) + OpenSubtitles through Stremio's free addon. No API key needed.
// To use another service later, only this file has to change (keep the same exports).
const fs=require('fs'),path=require('path');
const CINE=process.env.ANI_CINEMETA||'https://v3-cinemeta.strem.io',OSUB=process.env.ANI_OSUB||'https://opensubtitles-v3.strem.io';
const LANG={eng:'English',ara:'Arabic',fre:'French',fra:'French',spa:'Spanish',spl:'Spanish (LatAm)',por:'Portuguese',pob:'Portuguese (Brazil)',ger:'German',deu:'German',ita:'Italian',rus:'Russian',tur:'Turkish',jpn:'Japanese',kor:'Korean',chi:'Chinese',zht:'Chinese (Traditional)',zhc:'Chinese (Simplified)',zho:'Chinese',hin:'Hindi',ind:'Indonesian',vie:'Vietnamese',tha:'Thai',pol:'Polish',dut:'Dutch',nld:'Dutch',swe:'Swedish',nor:'Norwegian',dan:'Danish',fin:'Finnish',ell:'Greek',gre:'Greek',heb:'Hebrew',per:'Persian',fas:'Persian',rum:'Romanian',ron:'Romanian',hun:'Hungarian',cze:'Czech',ces:'Czech',ukr:'Ukrainian',bul:'Bulgarian',hrv:'Croatian',srp:'Serbian',slv:'Slovenian',may:'Malay',msa:'Malay',ben:'Bengali',urd:'Urdu',kur:'Kurdish',cat:'Catalan',fil:'Filipino',tgl:'Filipino',slo:'Slovak',slk:'Slovak',lit:'Lithuanian',lav:'Latvian',est:'Estonian',alb:'Albanian',mac:'Macedonian',bos:'Bosnian',aze:'Azerbaijani',geo:'Georgian',arm:'Armenian',tam:'Tamil',tel:'Telugu',mal:'Malayalam',sin:'Sinhala',nep:'Nepali',mya:'Burmese',khm:'Khmer'};
const ok=(x,ms)=>AbortSignal.timeout(ms||15000);
module.exports=function createSubs(o){
  const dir=o.dir;fs.mkdirSync(dir,{recursive:true});
  const mem=new Map();
  const jget=async(u,ms)=>{const r=await fetch(u,{headers:{'User-Agent':o.UA||'Mozilla/5.0'},signal:ok(0,ms)});if(!r.ok)throw new Error('HTTP '+r.status);return r.json()};
  const norm=s=>String(s).toLowerCase().replace(/[^\p{L}\p{N}]+/gu,' ').trim();
  const fileOf=k=>path.join(dir,'meta-'+k.replace(/[^\w.-]/g,'_')+'.json');
  async function cached(k,ttl,fn){
    const m=mem.get(k);if(m&&Date.now()-m.t<ttl)return m.v;
    const f=fileOf(k);let disk=null;
    try{disk=JSON.parse(fs.readFileSync(f,'utf8'))}catch{}
    if(disk&&Date.now()-disk.t<ttl){mem.set(k,disk);return disk.v}
    try{const v=await fn();const e={t:Date.now(),v};mem.set(k,e);try{fs.writeFileSync(f,JSON.stringify(e))}catch{}return v}
    catch(e){if(disk){mem.set(k,disk);return disk.v}throw e}
  }
  // title -> imdb id
  async function imdbFor(title){
    return cached('s-'+norm(title),30*864e5,async()=>{
      const d=await jget(CINE+'/catalog/series/top/search='+encodeURIComponent(title)+'.json');
      const ms=(d.metas||[]).filter(m=>m&&m.imdb_id),t=norm(title);
      const best=ms.find(m=>norm(m.name)===t)||ms.find(m=>norm(m.name).startsWith(t))||ms[0];
      return best?{id:best.imdb_id,name:best.name}:null;
    });
  }
  async function meta(imdb){
    return cached('m-'+imdb,7*864e5,async()=>{
      const d=(await jget(CINE+'/meta/series/'+imdb+'.json')).meta||{};
      const seasons={},eps={};
      for(const v of d.videos||[]){const s=+v.season,e=+(v.episode??v.number);if(!(s>0)||!(e>0))continue;seasons[s]=(seasons[s]||0)+1;(eps[s]=eps[s]||{})[e]={t:v.title||v.name||'',th:v.thumbnail||'',ov:v.overview||''}}
      return{id:imdb,name:d.name||'',year:d.year||d.releaseInfo||'',rating:d.imdbRating||'',desc:d.description||'',genres:d.genres||[],runtime:d.runtime||'',bg:d.background||'',seasons,eps};
    });
  }
  async function info(title){
    const f=await imdbFor(title);if(!f)return null;
    return meta(f.id);
  }
  // pick the IMDb season for an entry. Numbered seasons are trusted; otherwise the season whose episode count matches.
  function pickSeason(m,season,count){
    if(season>0)return season;
    const c=Object.entries(m.seasons).filter(([s,n])=>+s>0&&n===count).map(([s])=>+s);
    return c.length===1?c[0]:0;
  }
  async function find({title,season,episode,count,offset}){
    const m=await info(title);
    if(!m)return{subs:[],reason:'Show not found on Cinemeta'};
    const s=pickSeason(m,+season||0,+count||0);
    if(!s)return{subs:[],reason:'Could not tell which season this is'};
    const e=(+episode||0)+(+offset||0);
    if(!(e>0))return{subs:[],reason:'Special episodes are not supported'};
    const d=await cached('x-'+m.id+'-'+s+'-'+e,864e5,()=>jget(OSUB+'/subtitles/series/'+m.id+':'+s+':'+e+'.json',20000));
    const by=new Map();
    for(const t of d.subtitles||[]){
      if(!t||!t.url||!t.lang)continue;
      const g=by.get(t.lang)||{lang:t.lang,label:LANG[t.lang]||t.lang.toUpperCase(),count:0,url:t.url};
      g.count++;by.set(t.lang,g);
    }
    const subs=[...by.values()].sort((a,b)=>(a.lang==='ara'?-1:b.lang==='ara'?1:0)||(a.lang==='eng'?-1:b.lang==='eng'?1:0)||a.label.localeCompare(b.label));
    return{subs,season:s,episode:e,imdb:m.id};
  }
  const toVtt=txt=>{
    txt=txt.replace(/^﻿/,'').replace(/\r\n?/g,'\n').trim();
    if(/^WEBVTT/.test(txt))return txt+'\n';
    return'WEBVTT\n\n'+txt.replace(/(\d{1,2}:\d{2}:\d{2}),(\d{1,3})/g,'$1.$2').replace(/(\d{1,2}:\d{2}),(\d{1,3})(?=\s*-->|\s*$)/gm,'$1.$2')+'\n';
  };
  async function fetchVtt(url){
    const r=await fetch(url,{headers:{'User-Agent':o.UA||'Mozilla/5.0'},signal:ok(0,25000)});
    if(!r.ok)throw new Error('HTTP '+r.status);
    let b=Buffer.from(await r.arrayBuffer());
    if(b.length>3&&b[0]===0x50&&b[1]===0x4b)throw new Error('zip not supported');
    let t=new TextDecoder('utf-8').decode(b);
    if(t.includes('�')&&/-->/.test(t)===false)throw new Error('unreadable');
    return toVtt(t);
  }
  return{find,info,fetchVtt,toVtt,LANG};
};
